class Constants {
  /// Image Base URL
  static final image = 'xxxxxxxxxxx';

  static final iosId = 'xxxxxxxxxxx';
  static final androidId = 'xxxxxxxxxxx';

  static final shareMessage = 'xxxxxxxxxxx ';

  static final stripeCountry = 'xx';
  static final stripeShopName = 'xxxxxxxxxxx';

  /// App Introduction (AKA Onboarding) Screens.
  /// Please add a [title], [body] & [image]
  /// [is_asset] is for image if image coming from network or local.
  static List<Map<String, dynamic>> introductionScreens() {
    return [
      {
        'title': 'Best Garage App',
        'body': 'Offer unlimited motor services to customers',
        'image':
            'https://image.freepik.com/free-vector/by-my-car-illustration-concept_114360-870.jpg',
        'is_asset': false,
      },
      {
        'title': 'Multi-Functional',
        'body':
            'Suitable for Cars, Bikes, Motor Vehicles and all kinds of Automobiles.',
        'image':
            'https://image.freepik.com/free-vector/two-men-having-car-accident-isolated-flat-vector-illustration-cartoon-people-looking-automobile-damage_74855-8655.jpg',
        'is_asset': false,
      },
      {
        'title': 'One Stop Vehicle App',
        'body':
            'Offer Cleaning, Detailing, Servicing, Repairing, Tyres, Recovery and other services',
        'image':
            'https://image.freepik.com/free-vector/city-driver-concept-illustration_114360-2648.jpg',
        'is_asset': false,
      },
    ];
  }
}
