import 'package:flutter/material.dart';

class Assets {
  static final splash = 'assets/images/splash.png';
  static final logoTransparent = 'assets/images/logo_transparent.png';
  static final logoIcon = 'assets/images/logo_icon.png';

  static final iconBookNow = 'assets/images/book_now.png';
  static final iconMyBooking = 'assets/images/my_bookings.png';

  static final imgAuthentication = 'assets/images/authentication.png';
  static final imgEmpty = 'assets/images/empty.png';

  static final imgMap = 'assets/images/maps.jpg';

  static final imgSuccess = 'assets/images/success.gif';

  static final imgBlank = AssetImage('assets/images/blank.jpg');

  static NetworkImage avatar(String name) {
    return NetworkImage('https://ui-avatars.com/api/?name=$name');
  }
}
