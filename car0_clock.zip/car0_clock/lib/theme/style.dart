import 'package:flutter/material.dart';

ThemeData get theme {
  return ThemeData(
    primarySwatch: Colors.blue,
    primaryColor: Colors.blue.shade800,
    appBarTheme: AppBarTheme(
      color: Colors.blue.shade800,
      elevation: 0,
    ),
  );
}

InputDecoration inputDecoration(String label) {
  return InputDecoration(
    labelText: label,
    filled: true,
    fillColor: Colors.white,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
    ),
  );
}

InputDecoration contactInputDecoration(String hint, IconData icon) {
  return InputDecoration(
    prefixIcon: Icon(icon, color: Colors.blue.shade800),
    border: OutlineInputBorder(),
    hintText: hint,
  );
}
