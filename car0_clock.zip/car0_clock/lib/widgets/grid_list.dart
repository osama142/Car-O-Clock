import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class GridList extends StatelessWidget {
  final int itemCount;
  final IndexedWidgetBuilder itemBuilder;
  final double mainAxisSpacing;
  final double crossAxisSpacing;
  final int crossAxisCount;
  final cellHeight;
  final EdgeInsetsGeometry padding;
  final bool primary;
  final bool shrinkWrap;

  GridList({
    required this.itemCount,
    required this.itemBuilder,
    this.mainAxisSpacing = 3,
    this.crossAxisSpacing = 2,
    this.crossAxisCount = 2,
    this.cellHeight = 180,
    this.padding = EdgeInsets.zero,
    this.primary = false,
    this.shrinkWrap = true,
  });

  double calculateAspectRatio(BuildContext context) {
    final width =
        (context.screenWidth - ((crossAxisCount - 1) * crossAxisSpacing)) /
            crossAxisCount;
    return width / cellHeight;
  }

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: shrinkWrap,
      itemCount: itemCount,
      primary: primary,
      padding: padding,
      itemBuilder: itemBuilder,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        mainAxisSpacing: mainAxisSpacing,
        crossAxisSpacing: crossAxisSpacing,
        childAspectRatio: calculateAspectRatio(context),
      ),
    );
  }
}
