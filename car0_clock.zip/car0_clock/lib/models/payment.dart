class Payment {
  late String publicKey;
  late String customerId;
  late String paymentIntent;
  late String ephemeralKey;

  Payment({
    required this.publicKey,
    required this.customerId,
    required this.paymentIntent,
    required this.ephemeralKey,
  });

  Payment.fromJson(Map<String, dynamic> json) {
    publicKey = json['key'];
    customerId = json['data']['customer'];
    paymentIntent = json['data']['payment_intent'];
    ephemeralKey = json['data']['ephemeral_key'];
  }
}
