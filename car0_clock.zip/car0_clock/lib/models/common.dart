class Faq {
  late int id;
  late String title;
  late String description;

  Faq({
    required this.id,
    required this.title,
    required this.description,
  });

  Faq.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    description = json['description'];
  }
}

class ContactLinks {
  late String title;
  late String? value;

  ContactLinks({
    required this.title,
    required this.value,
  });

  ContactLinks.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    value = json['value'];
  }
}

class Common {
  late String terms;
  late String privacy;
  late List<Faq> faqs;
  late List<ContactLinks> links;

  Common({
    required this.terms,
    required this.privacy,
    required this.faqs,
    required this.links,
  });

  Common.fromJson(Map<String, dynamic> json) {
    terms = json['terms'];
    privacy = json['privacy'];
    faqs = [];
    links = [];

    for (final el in json['faqs']) {
      faqs.add(Faq.fromJson(el));
    }

    for (final el in json['links']) {
      links.add(ContactLinks.fromJson(el));
    }
  }
}
