// import 'package:car0_clock/models/booking.dart';
import 'package:car_detailing/models/booking.dart';
// import "package:car_detailing/models/booking.dart";

class Review {
  late int id;
  late num? rating;
  late String review;
  late Booking booking;

  Review({
    required this.id,
    required this.rating,
    required this.review,
    required this.booking,
  });

  Review.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    rating = json['rating'];
    review = json['review'];
    booking = Booking.fromJson(json['booking']);
  }
}

class ReviewResponse {
  late List<Review> reviews;

  ReviewResponse({required this.reviews});

  ReviewResponse.fromJson(List<dynamic> json) {
    reviews = <Review>[];

    for (final el in json) {
      reviews.add(Review.fromJson(el));
    }
  }
}
