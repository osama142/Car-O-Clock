class AuthResponse {
  late String token;
  late User user;

  AuthResponse({
    required this.token,
    required this.user,
  });

  AuthResponse.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    user = User.fromJson(json['user']);
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['token'] = token;
    data['user'] = user.toJson();

    return data;
  }
}

class User {
  late int id;
  late String name;
  late String email;
  late String mobile;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.mobile,
  });

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    mobile = json['mobile'];
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['email'] = email;
    data['mobile'] = mobile;
    return data;
  }
}
