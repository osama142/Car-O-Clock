import 'package:car_detailing/commons/commons.dart';

class Tax {
  late String title;
  late String type;
  late num amount;

  Tax({
    required this.title,
    required this.type,
    required this.amount,
  });

  Tax.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    type = json['type'];
    amount = json['amount'];
  }
}

class Offer {
  late int id;
  late String title;
  late String code;
  late String image;
  late String description;
  late String type;
  late num amount;
  late num minimumAmount;

  Offer({
    required this.id,
    required this.title,
    required this.code,
    required this.image,
    required this.description,
    required this.type,
    required this.amount,
    required this.minimumAmount,
  });

  Offer.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    code = json['code'];
    image = Constants.image + json['image'];
    description = json['description'];
    type = json['type'];
    amount = json['amount'];
    minimumAmount = json['minimum_amount'] ?? 0;
  }
}

class OfferResponse {
  late List<Offer> offers;

  OfferResponse({required this.offers});

  OfferResponse.fromJson(List<dynamic> json) {
    offers = [];

    for (final el in json) {
      offers.add(Offer.fromJson(el));
    }
  }
}

class TotalResponse {
  late num total;
  late List<Tax> taxes;

  TotalResponse({
    required this.total,
    required this.taxes,
  });

  TotalResponse.fromJson(Map<String, dynamic> json) {
    total = json['total'];
    taxes = [];

    for (final el in json['taxes']) {
      taxes.add(Tax.fromJson(el));
    }
  }
}
