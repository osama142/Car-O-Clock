class CardItem {
  late String id;
  late String name;
  late String number;
  late String expiry;
  late String brand;
  late String country;

  CardItem({
    required this.id,
    required this.name,
    required this.number,
    required this.expiry,
    required this.brand,
    required this.country,
  });

  CardItem.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    number = json['number'];
    expiry = json['expiry'];
    brand = json['brand'];
    country = json['country'];
  }
}

class CardResponse {
  late List<CardItem> cards;

  CardResponse({required this.cards});

  CardResponse.fromJson(List<dynamic> json) {
    cards = [];

    for (final el in json) {
      cards.add(CardItem.fromJson(el));
    }
  }
}
