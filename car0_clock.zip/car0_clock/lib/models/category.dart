import 'package:car_detailing/commons/commons.dart';

import 'service.dart';

class Category {
  late int id;
  late String title;
  late String? image;
  late bool selected;

  Category({
    required this.id,
    required this.title,
    required this.image,
    this.selected = false,
  });

  Category.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['name'];
    image = Constants.image + json['image'];
    this.selected = false;
  }
}

class CategoryDetailsResponse {
  late List<Category> categories;
  late List<Service> services;

  CategoryDetailsResponse({
    required this.categories,
    required this.services,
  });

  CategoryDetailsResponse.fromJson(Map<String, dynamic> json) {
    categories = [];
    services = [];

    categories.add(Category(
      id: 0,
      title: 'All',
      image: 'https://cdn-icons-png.flaticon.com/512/481/481156.png',
      selected: true,
    ));

    for (final el in json['categories']) {
      categories.add(Category.fromJson(el));
    }

    if (categories.length == 1) {
      categories.clear();
    }

    for (final el in json['services']) {
      services.add(Service.fromJson(el));
    }
  }
}

class CategoryResponse {
  late List<Category> categories;

  CategoryResponse({required this.categories});

  CategoryResponse.fromJson(List<dynamic> json) {
    categories = [];

    for (final el in json) {
      categories.add(Category.fromJson(el));
    }
  }
}

class HomeResponse {
  late List<Category> categories;
  late List<String> sliders;

  HomeResponse({
    required this.categories,
    required this.sliders,
  });

  HomeResponse.fromJson(Map<String, dynamic> json) {
    categories = [];
    sliders = [];

    for (final el in json['sliders']) {
      sliders.add(Constants.image + el['image']);
    }

    for (final el in json['categories']) {
      categories.add(Category.fromJson(el));
    }

    categories.add(Category(
      id: 0,
      title: 'All',
      image: 'https://cdn-icons-png.flaticon.com/512/481/481156.png',
    ));
  }
}
