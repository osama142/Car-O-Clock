import 'package:car_detailing/models/models.dart';

class Booking {
  late int id;
  late String bookingId;
  late String name;
  late String email;
  late String phone;
  late String vehicle;
  late String time;
  late DateTime date;
  late String status;
  late String paymentMethod;
  late Service service;
  late num total;
  late List<Question> questions;

  Booking({
    required this.bookingId,
    required this.name,
    required this.email,
    required this.phone,
    required this.vehicle,
    required this.time,
    required this.date,
    required this.id,
    required this.status,
    required this.paymentMethod,
    required this.service,
    required this.total,
    required this.questions,
  });

  Booking.fromJson(Map<String, dynamic> json) {
    bookingId = json['booking_id'];
    name = json['name'];
    email = json['email'];
    phone = json['phone'];
    vehicle = json['vehicle'];
    time = json['time'];
    id = json['id'];
    status = json['status'];
    total = json['total'];
    paymentMethod = json['payment_method'];
    date = DateTime.parse(json['date']);
    service = Service.fromJson(json['service']);

    questions = [];

    if (json['answers'] != null) {
      for (final question in json['answers']) {
        questions.add(Question.fromJson(question));
      }
    }
  }
}

class BookingResponse {
  late List<Booking> bookings;

  BookingResponse({required this.bookings});

  BookingResponse.fromJson(List<dynamic> json) {
    bookings = [];

    for (final el in json) {
      bookings.add(Booking.fromJson(el));
    }
  }
}
