import 'package:car_detailing/commons/commons.dart';

class Service {
  late int id;
  late int categoryId;
  late int? subcategoryId;
  late String name;
  late String description;
  late String image;
  late String time;
  late num price;
  late bool onInspection;
  late List<Question> questions;

  late num rating;
  late num review;

  Service({
    required this.id,
    required this.categoryId,
    required this.subcategoryId,
    required this.name,
    required this.description,
    required this.image,
    required this.time,
    required this.price,
    required this.onInspection,
    required this.questions,
    required this.rating,
    required this.review,
  });

  Service.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    categoryId = json['category_id'];
    subcategoryId = json['subcategory_id'];
    name = json['name'];
    description = json['description'];
    image = Constants.image + json['image'];
    time = json['time'];
    price = json['price'];
    onInspection = json['on_inspection'];

    rating = json['rating'] ?? 0;
    review = json['reviews_count'] ?? 0;

    questions = [];

    if (json['questions'] != null) {
      for (final question in json['questions']) {
        questions.add(Question.fromJson(question));
      }
    }
  }
}

class Question {
  late String name;
  late String type;
  late List<String> choices;
  String? answer;

  Question({
    required this.name,
    required this.type,
    required this.choices,
    this.answer,
  });

  Question.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    type = json['type'];
    answer = json['answer'];
    choices = [];

    if (json['choices'] != null) {
      for (final choice in json['choices']) {
        try {
          choices.add(choice['name']);
        } catch ($e) {
          choices.add(choice);
        }
      }
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'type': type,
      'answer': answer,
      'choices': choices,
    };
  }
}
