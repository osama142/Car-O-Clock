import 'package:car_detailing/api/api.dart';
import 'package:car_detailing/services/services.dart';
import 'package:car_detailing/states/states.dart';
import 'package:v1techx/v1techx.dart';

Future setupGet() async {
  final preferenceInstance = await PreferenceService.getInstance();
  locate.registerLazySingleton(() => preferenceInstance!);

  locate.registerLazySingleton(() => API());
  locate.registerLazySingleton(() => AuthService());
  locate.registerLazySingleton(() => RouterService());
  locate.registerLazySingleton(() => DrawerService());
  locate.registerLazySingleton(() => SettingsService());

  locate.registerFactory(() => SplashState());

  locate.registerFactory(() => IntroState());

  locate.registerFactory(() => AuthState());
  locate.registerFactory(() => LoginState());
  locate.registerFactory(() => RegisterState());
  locate.registerFactory(() => ForgotState());

  locate.registerFactory(() => MainState());
  locate.registerFactory(() => HomeState());

  locate.registerFactory(() => ServicesState());
  locate.registerFactory(() => ServiceDetailsState());

  locate.registerFactory(() => BookingState());
  locate.registerFactory(() => MyBookingState());
  locate.registerFactory(() => BookingDetailsState());
  locate.registerFactory(() => BookingReviewState());

  locate.registerFactory(() => AccountState());
  locate.registerFactory(() => EditProfileState());
  locate.registerFactory(() => PasswordState());
  locate.registerFactory(() => ManageCardState());
  locate.registerFactory(() => AllReviewState());

  locate.registerFactory(() => ContactState());
  locate.registerFactory(() => ReviewState());
  locate.registerFactory(() => HelpState());

  locate.registerFactory(() => MoreState());

  locate.registerFactory(() => SuccessState());
}
