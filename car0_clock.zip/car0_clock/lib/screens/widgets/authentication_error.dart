import 'package:car_detailing/commons/commons.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class AuthenticationError extends StatelessWidget {
  final String subtitle;
  final VoidCallback onPressed;

  const AuthenticationError({
    Key? key,
    required this.subtitle,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          Assets.imgAuthentication,
          height: 250,
          width: 250,
        ),
        'Sorry! You must be logged in'
            .text
            .xl
            .semiBold
            .color(Colors.red)
            .make(),
        4.heightBox,
        'Please login to access your $subtitle'.text.caption(context).make(),
        32.heightBox,
        GFButton(
          onPressed: onPressed,
          shape: GFButtonShape.pills,
          child: 'Sign In'.text.make(),
        ),
      ],
    ).centered();
  }
}
