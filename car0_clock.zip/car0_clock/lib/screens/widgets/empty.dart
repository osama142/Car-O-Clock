import 'package:car_detailing/commons/commons.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class Empty extends StatelessWidget {
  final String subtitle;

  const Empty({
    Key? key,
    required this.subtitle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          Assets.imgEmpty,
          height: 250,
          width: 250,
        ),
        'Sorry! No $subtitle Found'
            .text
            .xl
            .semiBold
            .color(context.primaryColor)
            .make(),
      ],
    ).centered();
  }
}
