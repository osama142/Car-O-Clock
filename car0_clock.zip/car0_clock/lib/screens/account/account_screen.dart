import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/screens/widgets/authentication_error.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<AccountState>(
      create: (context, state, child) {
        if (!state.auth.isLoggedIn) {
          return Scaffold(
            appBar: AppBar(
              title: 'My Account'.text.make(),
            ),
            body: AuthenticationError(
              subtitle: 'account',
              onPressed: () => state.openAuthScreen(context),
            ),
          );
        }

        return Scaffold(
          appBar: AppBar(
            elevation: 0,
          ),
          body: LoadingOverlay(
            isLoading: state.isNestedBusy,
            child: Column(
              children: [
                ClipPath(
                  clipper: MultipleRoundedCurveClipper(),
                  child: Container(
                    height: 130,
                    width: context.width,
                    color: context.primaryColor,
                    child: Column(
                      children: [
                        CircleAvatar(
                          backgroundImage: Assets.avatar(state.user.name),
                          radius: 32,
                        ),
                        4.heightBox,
                        state.user.name.text.bold.white.make(),
                        2.heightBox,
                        state.user.email.text.caption(context).white.make(),
                      ],
                    ),
                  ),
                ),
                ListTile(
                  leading: ImageIcon(AssetImage(Assets.iconMyBooking)),
                  title: 'My Bookings'.text.make(),
                  onTap: () => state.router.toMyBookingScreen(context),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                ),
                ListTile(
                  leading:
                      Icon(Icons.rate_review_outlined, color: Colors.green),
                  title: 'My Reviews'.text.make(),
                  onTap: () => state.router.toAllReviewScreen(context),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                ),
                ListTile(
                  leading: Icon(Icons.credit_card, color: Colors.indigo),
                  title: 'Manage Payment Card'.text.make(),
                  onTap: () => state.router.toManageCardScreen(context),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                ),
                ListTile(
                  leading: Icon(Icons.edit, color: context.primaryColor),
                  title: 'Edit Profile'.text.make(),
                  onTap: () => state.router.toEditProfileScreen(context),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                ),
                ListTile(
                  leading: Icon(Icons.lock, color: Colors.purple),
                  title: 'Change Password'.text.make(),
                  onTap: () => state.router.toChangePasswordScreen(context),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                ),
                Divider(),
                ListTile(
                  leading: Icon(Icons.power_settings_new, color: Colors.red),
                  title: 'Logout'.text.make(),
                  onTap: () => state.logout(context),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
