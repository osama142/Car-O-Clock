import 'package:car_detailing/commons/assets.dart';
import 'package:car_detailing/states/states.dart';
import 'package:car_detailing/theme/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:v1techx/v1techx.dart';

class EditProfileScreen extends StatelessWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<EditProfileState>(
      onStateReady: (state) => state.init(),
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(),
          body: LoadingOverlay(
            isLoading: state.isBusy,
            child: Column(
              children: [
                ClipPath(
                  clipper: MultipleRoundedCurveClipper(),
                  child: Container(
                    height: 130,
                    width: context.width,
                    color: context.primaryColor,
                    child: Column(
                      children: [
                        CircleAvatar(
                          backgroundImage: Assets.avatar(state.user.name),
                          radius: 32,
                        ),
                        4.heightBox,
                        state.user.name.text.bold.white.make(),
                        2.heightBox,
                        state.user.email.text.caption(context).white.make(),
                      ],
                    ),
                  ),
                ),
                16.heightBox,
                _form(state),
                GFButton(
                  elevation: 4,
                  color: context.primaryColor,
                  shape: GFButtonShape.pills,
                  fullWidthButton: true,
                  onPressed: () => state.update(context),
                  child: 'UPDATE'.text.bold.make(),
                ).h(40).px16(),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _form(EditProfileState state) {
    return Form(
      key: state.form,
      child: Column(
        children: [
          TextFormField(
            controller: state.nameController,
            keyboardType: TextInputType.name,
            validator: requiredValidator,
            textCapitalization: TextCapitalization.words,
            decoration: inputDecoration('Name'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.emailController,
            keyboardType: TextInputType.emailAddress,
            validator: validator.email().build(),
            decoration: inputDecoration('Email'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.mobileController,
            keyboardType: TextInputType.phone,
            validator: validator.phone().build(),
            decoration: inputDecoration('Mobile'),
          ),
          16.heightBox,
        ],
      ),
    ).px16();
  }
}
