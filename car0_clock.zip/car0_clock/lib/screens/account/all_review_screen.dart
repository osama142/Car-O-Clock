import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:v1techx/v1techx.dart';

class AllReviewScreen extends StatelessWidget {
  const AllReviewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<AllReviewState>(
      onStateReady: (state) => state.getReviews(),
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(title: 'My Reviews'.text.make()),
          body: _body(context, state),
        );
      },
    );
  }

  Widget _body(BuildContext context, AllReviewState state) {
    if (state.isBusy) return GFLoader();

    return ListView.separated(
      itemCount: state.reviews.length,
      separatorBuilder: (_, __) => 16.heightBox,
      itemBuilder: (_, int index) => _ReviewItem(
        state: state,
        item: state.reviews[index],
      ),
    );
  }
}

class _ReviewItem extends StatelessWidget {
  final AllReviewState state;
  final Review item;

  const _ReviewItem({
    Key? key,
    required this.state,
    required this.item,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(
            item.booking.service.image,
            height: 60,
            width: 60,
            fit: BoxFit.cover,
          ),
          16.widthBox,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              item.booking.service.name.text.bold.make(),
              4.heightBox,
              item.review.text.caption(context).maxLines(1).make(),
              16.heightBox,
              Row(
                children: [
                  RatingBar.builder(
                    initialRating: item.rating?.toDouble() ?? 0.0,
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 5,
                    itemSize: 18,
                    itemBuilder: (context, _) => Icon(
                      Icons.star,
                      color: context.primaryColor,
                    ),
                    onRatingUpdate: (double value) {},
                  ),
                  Spacer(),
                  Row(
                    children: [
                      Icon(Icons.date_range, size: 18),
                      4.widthBox,
                      '${parseDate(item.booking.date)}'.text.make(),
                    ],
                  ),
                ],
              ),
            ],
          ).expand(),
        ],
      ).p16(),
    ).onInkTap(() {
      state.router.toBookingReviewScreen(context, item.booking);
    });
  }
}
