import 'package:awesome_card/awesome_card.dart';
import 'package:awesome_card/credit_card.dart';
import 'package:car_detailing/screens/widgets/empty.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class ManageCardScreen extends StatelessWidget {
  const ManageCardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<ManageCardState>(
      onStateReady: (state) => state.getCards(),
      create: (context, state, child) {
        return Scaffold(
          backgroundColor: state.cards.isEmpty? Colors.white: null,
          appBar: AppBar(
            title: 'Manage Card'.text.make(),
          ),
          body: _body(context, state),
        );
      },
    );
  }

  Widget _body(BuildContext context, ManageCardState state) {
    if (state.isBusy) return GFLoader();

    if (state.cards.isEmpty) return Empty(subtitle: 'Saved Cards');

    return LoadingOverlay(
      isLoading: state.isNestedBusy,
      child: ListView.separated(
        itemCount: state.cards.length,
        separatorBuilder: (_, __) => 16.heightBox,
        itemBuilder: (_, int index) {
          final card = state.cards[index];

          return Stack(
            children: [
              CreditCard(
                cardNumber: card.number,
                cardExpiry: card.expiry,
                cardHolderName: card.name,
                frontBackground: CardBackgrounds.white,
                frontTextColor: Colors.black,
                backBackground: CardBackgrounds.white,
                textExpDate: 'Exp. Date',
                textName: 'Name',
                textExpiry: 'MM/YY',
                showShadow: true,
              ),
              GFIconButton(
                onPressed: () => state.remove(card, context),
                type: GFButtonType.transparent,
                icon: Icon(Icons.delete, color: Colors.red),
              ),
            ],
          ).p8();
        },
      ),
    );
  }
}
