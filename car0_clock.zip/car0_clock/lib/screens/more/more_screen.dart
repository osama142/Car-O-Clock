import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<MoreState>(
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(title: 'More'.text.make()),
          body: Column(
            children: [
              // ListTile(
              //   leading: Icon(Icons.rate_review_outlined),
              //   title: 'Reviews & Feedback'.text.make(),
              //   onTap: () => state.router.toReviewScreen(context),
              // ),
              ListTile(
                leading: Icon(LineIcons.info),
                title: 'Help & Info'.text.make(),
                onTap: () => state.router.toHelpScreen(context),
              ),
              ListTile(
                leading: Icon(Icons.star_border_outlined),
                title: 'Rate App'.text.make(),
                onTap: state.review,
              ),
              ListTile(
                leading: Icon(LineIcons.share),
                title: 'Share App'.text.make(),
                onTap: state.share,
              ),
              ListTile(
                leading: Icon(LineIcons.phone),
                title: 'Contact Us'.text.make(),
                onTap: () => state.router.toContactScreen(context),
              ),
            ],
          ),
        );
      },
    );
  }
}
