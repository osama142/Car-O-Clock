import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/states.dart';
import 'package:car_detailing/theme/style.dart';
import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class BookingQuestion extends StatelessWidget {
  final BookingState state;

  const BookingQuestion({
    Key? key,
    required this.state,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<BookingState>.value(
      value: state,
      child: Consumer<BookingState>(
        builder: (context, state, child) {
          return Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: AppBar(
              title: 'Questions'.text.make(),
            ),
            body: SingleChildScrollView(
              child: Column(
                children: [
                  _form(context),
                  32.heightBox,
                  GFButton(
                    onPressed: () => state.validate(context),
                    shape: GFButtonShape.square,
                    elevation: 4,
                    fullWidthButton: true,
                    child: 'CONTINUE'.text.bold.make(),
                  ).h(50),
                ],
              ).p16(),
            ),
          );
        },
      ),
    );
  }

  Widget _form(BuildContext context) {
    return Form(
      key: state.form,
      child: Column(
        children: [
          TextFormField(
            controller: state.nameController,
            keyboardType: TextInputType.name,
            validator: requiredValidator,
            textCapitalization: TextCapitalization.words,
            textInputAction: TextInputAction.done,
            decoration: inputDecoration('Name'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.emailController,
            keyboardType: TextInputType.emailAddress,
            validator: validator.email().build(),
            textInputAction: TextInputAction.done,
            decoration: inputDecoration('Email'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.mobileController,
            keyboardType: TextInputType.phone,
            textInputAction: TextInputAction.done,
            validator: validator.phone().build(),
            decoration: inputDecoration('Mobile'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.vehicleController,
            keyboardType: TextInputType.text,
            validator: requiredValidator,
            textInputAction: TextInputAction.done,
            decoration: inputDecoration('Vehicle Registration Number'),
          ),
          16.heightBox,
          Row(
            children: [
              _PickerContainer(
                value: state.stringDate,
                onPressed: () => state.pickDate(context),
              ).expand(),
              8.widthBox,
              _PickerContainer(
                value: state.time,
                onPressed: () => state.pickTime(context),
              ).expand(),
            ],
          ),
          16.heightBox,
          _Questions(questions: state.service.questions),
        ],
      ),
    );
  }
}

class _Questions extends StatelessWidget {
  final List<Question> questions;

  const _Questions({
    Key? key,
    required this.questions,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      primary: false,
      shrinkWrap: true,
      itemCount: questions.length,
      separatorBuilder: (_, __) => 16.heightBox,
      itemBuilder: (_, int index) {
        final item = questions[index];
        final type = item.type;
        final keyboardType =
            type == 'number' ? TextInputType.number : TextInputType.text;

        if (type == 'radio') {
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                item.name.text.semiBold.make(),
                8.heightBox,
                CustomRadioButton(
                  elevation: 0,
                  autoWidth: true,
                  unSelectedColor: Theme.of(context).canvasColor,
                  buttonLables: item.choices,
                  buttonValues: item.choices,
                  buttonTextStyle: ButtonTextStyle(
                    selectedColor: Colors.white,
                    unSelectedColor: Colors.black,
                    textStyle: TextStyle(fontSize: 16),
                  ),
                  radioButtonValue: (value) {
                    item.answer = value.toString();
                  },
                  selectedColor: context.primaryColor,
                ),
              ],
            ).p16(),
          );
        }

        if (type == 'checkbox') {
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                item.name.text.semiBold.make(),
                8.heightBox,
                CustomCheckBoxGroup(
                  elevation: 0,
                  autoWidth: true,
                  unSelectedColor: Theme.of(context).canvasColor,
                  buttonLables: item.choices,
                  buttonValuesList: item.choices,
                  buttonTextStyle: ButtonTextStyle(
                    selectedColor: Colors.white,
                    unSelectedColor: Colors.black,
                    textStyle: TextStyle(fontSize: 16),
                  ),
                  checkBoxButtonValues: (value) {
                    item.answer = value.toString();
                  },
                  selectedColor: context.primaryColor,
                ),
              ],
            ).p16(),
          );
        }

        if (type == 'dropdown') {
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                item.name.text.semiBold.make(),
                8.heightBox,
                DropdownSearch<String>(
                  mode: Mode.MENU,
                  items: item.choices,
                  validator: requiredValidator,
                  onChanged: (value) => item.answer = value,
                  selectedItem: item.answer,
                ),
              ],
            ).p16(),
          );
        }

        return TextFormField(
          keyboardType: keyboardType,
          validator: requiredValidator,
          onChanged: (value) => item.answer = value,
          textInputAction: TextInputAction.done,
          decoration: inputDecoration(item.name),
        );
      },
    );
  }
}

class _PickerContainer extends StatelessWidget {
  final String value;
  final VoidCallback onPressed;

  const _PickerContainer({
    Key? key,
    required this.value,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: context.width,
      height: 60,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(),
        borderRadius: BorderRadius.circular(12),
      ),
      child: value.text.make().centered(),
    ).onInkTap(onPressed);
  }
}
