import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class CheckoutScreen extends StatelessWidget {
  final BookingState state;

  const CheckoutScreen({
    Key? key,
    required this.state,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<BookingState>.value(
      value: state,
      child: Consumer<BookingState>(
        builder: (context, state, child) {
          return Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: AppBar(title: 'Checkout'.text.make()),
            body: LoadingOverlay(
              isLoading: state.isNestedBusy,
              child: Column(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        _ServiceItem(state: state, service: state.service),
                        _UserDetails(state: state),
                        _CardItem(
                          title: 'Apply Offer',
                          child: GFButton(
                            onPressed: () => state.openOffers(context),
                            fullWidthButton: true,
                            child: 'APPLY COUPON'.text.make(),
                          ),
                        ),
                        _PriceDetails(state: state),
                      ],
                    ),
                  ).expand(),
                  Row(
                    children: [
                      GFButton(
                        onPressed: () => context.pop('cash'),
                        shape: GFButtonShape.square,
                        type: state.service.onInspection
                            ? GFButtonType.solid
                            : GFButtonType.outline,
                        fullWidthButton: true,
                        child: 'PAY BY CASH'.text.bold.make(),
                      ).h(50).expand(),
                      GFButton(
                        onPressed: () => context.pop('stripe'),
                        shape: GFButtonShape.square,
                        elevation: 4,
                        fullWidthButton: true,
                        child: 'PAY BY CARD'.text.bold.make(),
                      )
                          .h(50)
                          .expand()
                          .hide(isVisible: !state.service.onInspection),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ServiceItem extends StatelessWidget {
  final BookingState state;
  final Service service;

  const _ServiceItem({
    Key? key,
    required this.state,
    required this.service,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _CardItem(
      title: 'Service Details',
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(
            service.image,
            fit: BoxFit.cover,
            height: 80,
            width: 80,
          ),
          16.widthBox,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Row(
                    children: [
                      Icon(Icons.date_range, size: 18),
                      4.widthBox,
                      '${state.stringDate}'.text.make(),
                    ],
                  ).expand(),
                  Row(
                    children: [
                      Icon(Icons.timer, size: 18),
                      4.widthBox,
                      '${state.time}'.text.caption(context).make(),
                    ],
                  ).expand(),
                ],
              ),
              16.heightBox,
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  service.name.text.bold.make().expand(),
                  4.widthBox,
                ],
              ),
              8.heightBox,
              Row(
                children: [
                  Row(
                    children: [
                      Icon(Icons.timer, size: 18),
                      4.widthBox,
                      service.time.text.make(),
                    ],
                  ).expand(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Icon(FontAwesomeIcons.moneyBillAlt, size: 14),
                      8.widthBox,
                      '${state.settings.symbol}${service.price}'
                          .text
                          .semiBold
                          .size(18)
                          .color(context.primaryColor)
                          .make(),
                    ],
                  ).expand(),
                ],
              ),
            ],
          ).expand(),
        ],
      ),
    );
  }
}

class _UserDetails extends StatelessWidget {
  final BookingState state;

  const _UserDetails({Key? key, required this.state}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _CardItem(
      title: 'Customer Details',
      child: Column(
        children: [
          _RowItem(title: 'Name', value: state.nameController.text),
          _RowItem(title: 'Email', value: state.emailController.text),
          _RowItem(title: 'Phone', value: state.auth.user?.mobile ?? ''),
          _RowItem(title: 'Vehicle', value: state.vehicleController.text),
        ],
      ),
    );
  }
}

class _PriceDetails extends StatelessWidget {
  final BookingState state;

  const _PriceDetails({Key? key, required this.state}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final symbol = state.settings.symbol;

    return _CardItem(
      title: 'Price Details',
      child: Column(
        children: [
          _RowItem(
            title: 'Price',
            value: '$symbol' + state.service.price.toString(),
          ),
          ListView.builder(
            shrinkWrap: true,
            primary: false,
            itemCount: state.taxes.length,
            itemBuilder: (_, int index) {
              final item = state.taxes[index];

              if (item.type == 'flat') {
                return _RowItem(
                  title: item.title,
                  value: '$symbol' + item.amount.toDoubleStringAsFixed(),
                );
              }

              final amount = (item.amount * state.service.price) / 100;

              return _RowItem(
                title:
                    item.title + ' (${item.amount.toDoubleStringAsFixed()}%)',
                value: '$symbol' + amount.toDoubleStringAsFixed(),
              );
            },
          ),
          _RowItem(
            title: 'Coupon',
            value: state.offer?.code ?? '',
          ).hide(isVisible: state.offer != null),
          Divider(),
          _RowItem(
            title: 'Total',
            value: '$symbol' + state.total.toDoubleStringAsFixed(),
          ),
        ],
      ),
    );
  }
}

class _RowItem extends StatelessWidget {
  final String title;
  final String value;

  const _RowItem({
    Key? key,
    required this.title,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        title.text.semiBold.make(),
        Spacer(),
        value.text.semiBold.make(),
      ],
    ).py8();
  }
}

class _CardItem extends StatelessWidget {
  final String title;
  final Widget child;

  const _CardItem({
    Key? key,
    required this.title,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          title.text.caption(context).semiBold.make(),
          Divider(),
          child,
        ],
      ).p16(),
    );
  }
}
