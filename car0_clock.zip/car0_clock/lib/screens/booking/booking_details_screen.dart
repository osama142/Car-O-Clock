import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class BookingDetailsScreen extends StatelessWidget {
  final Booking booking;

  const BookingDetailsScreen({
    Key? key,
    required this.booking,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<BookingDetailsState>(
      onStateReady: (state) => state.init(booking),
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(
            title: 'Booking #${state.booking.id}'.text.make(),
          ),
          body: Column(
            children: [
              ListView(
                children: [
                  _ServiceItem(
                    booking: state.booking,
                    service: state.booking.service,
                    symbol: state.symbol,
                  ),
                  _UserDetails(booking: state.booking),
                  _AnswerDetails(booking: state.booking),
                  _PaymentDetails(booking: state.booking, symbol: state.symbol),
                ],
              ).expand(),
              GFButton(
                onPressed: () => state.router.toBookingReviewScreen(
                  context,
                  state.booking,
                ),
                fullWidthButton: true,
                child: '⭐️⭐️⭐️⭐️⭐️\nPLEASE LEAVE A REVIEW'.text.center.make(),
              ).h(60).hide(isVisible: state.booking.status == 'complete'),
            ],
          ),
        );
      },
    );
  }
}

class _ServiceItem extends StatelessWidget {
  final Booking booking;
  final Service service;
  final String symbol;

  const _ServiceItem({
    Key? key,
    required this.booking,
    required this.service,
    required this.symbol,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _CardItem(
      title: 'Service Details',
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(
            service.image,
            fit: BoxFit.cover,
            height: 80,
            width: 80,
          ),
          16.widthBox,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Row(
                    children: [
                      Icon(Icons.date_range, size: 18),
                      4.widthBox,
                      '${parseDate(booking.date)}'.text.make(),
                    ],
                  ).expand(),
                  Row(
                    children: [
                      Icon(Icons.timer, size: 18),
                      4.widthBox,
                      '${booking.time}'.text.caption(context).make(),
                    ],
                  ).expand(),
                ],
              ),
              16.heightBox,
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  service.name.text.bold.make().expand(),
                  4.widthBox,
                  _Status(status: booking.status),
                ],
              ),
              8.heightBox,
              Row(
                children: [
                  Row(
                    children: [
                      Icon(Icons.timer, size: 18),
                      4.widthBox,
                      service.time.text.make(),
                    ],
                  ).expand(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Icon(FontAwesomeIcons.moneyBillAlt, size: 14),
                      8.widthBox,
                      '$symbol${service.price}'
                          .text
                          .semiBold
                          .size(18)
                          .color(context.primaryColor)
                          .make(),
                    ],
                  ).expand(),
                ],
              ),
            ],
          ).expand(),
        ],
      ),
    );
  }
}

class _UserDetails extends StatelessWidget {
  final Booking booking;

  const _UserDetails({Key? key, required this.booking}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _CardItem(
      title: 'Booking Details',
      child: Column(
        children: [
          _RowItem(title: 'Name', value: booking.name),
          _RowItem(title: 'Email', value: booking.email),
          _RowItem(title: 'Phone', value: booking.phone),
          _RowItem(title: 'Vehicle', value: booking.vehicle),
        ],
      ),
    );
  }
}

class _AnswerDetails extends StatelessWidget {
  final Booking booking;

  const _AnswerDetails({Key? key, required this.booking}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (booking.questions.isEmpty) return SizedBox.shrink();

    return _CardItem(
      title: 'Other Details',
      child: ListView.builder(
        itemCount: booking.questions.length,
        primary: false,
        shrinkWrap: true,
        itemBuilder: (_, int index) {
          final item = booking.questions[index];

          return _RowItem(title: item.name, value: item.answer ?? '');
        },
      ),
    );
  }
}

class _PaymentDetails extends StatelessWidget {
  final Booking booking;
  final String symbol;

  const _PaymentDetails({
    Key? key,
    required this.booking,
    required this.symbol,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _CardItem(
      title: 'Payment Details',
      child: Column(
        children: [
          _RowItem(title: 'Payment Method', value: booking.paymentMethod),
          _RowItem(
              title: 'Total',
              value: '$symbol${booking.total.toDoubleStringAsFixed()}'),
        ],
      ),
    );
  }
}

class _CardItem extends StatelessWidget {
  final String title;
  final Widget child;

  const _CardItem({
    Key? key,
    required this.title,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          title.text.caption(context).semiBold.make(),
          Divider(),
          child,
        ],
      ).p16(),
    );
  }
}

class _Status extends StatelessWidget {
  final String status;

  const _Status({
    Key? key,
    required this.status,
  }) : super(key: key);

  Color _statusColor() {
    if (status == 'pending') return Colors.grey.shade800;

    if (status == 'cancelled') return Colors.red.shade800;

    if (status == 'confirmed') return Colors.blue.shade800;

    return Colors.green.shade800;
  }

  @override
  Widget build(BuildContext context) {
    return status.text.xs.semiBold.uppercase.color(_statusColor()).make();
  }
}

class _RowItem extends StatelessWidget {
  final String title;
  final String value;

  const _RowItem({
    Key? key,
    required this.title,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        title.text.semiBold.make(),
        Spacer(),
        value.text.semiBold.make(),
      ],
    ).py8();
  }
}
