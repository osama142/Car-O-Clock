import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/states.dart';
import 'package:car_detailing/theme/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:v1techx/v1techx.dart';

class BookingReview extends StatelessWidget {
  final Booking booking;

  const BookingReview({
    Key? key,
    required this.booking,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<BookingReviewState>(
      onStateReady: (state) {
        state.init(booking);
        state.getReview();
      },
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(title: 'Booking Review'.text.make()),
          body: LoadingOverlay(
            isLoading: state.isBusy,
            child: SingleChildScrollView(
              child: Padding(
                padding: MediaQuery.of(context).viewInsets,
                child: Form(
                  key: state.form,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextFormField(
                        controller: state.reviewController,
                        validator: requiredValidator,
                        textAlign: TextAlign.justify,
                        maxLines: 3,
                        decoration:
                            contactInputDecoration('Review', Icons.message),
                      ),
                      16.heightBox,
                      'Rating'.text.semiBold.make().px4(),
                      RatingBar.builder(
                        initialRating: state.rating.toDouble(),
                        minRating: 1,
                        direction: Axis.horizontal,
                        allowHalfRating: true,
                        itemCount: 5,
                        itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                        itemBuilder: (context, _) => Icon(
                          Icons.star,
                          color: context.primaryColor,
                        ),
                        onRatingUpdate: state.updateRating,
                      ),
                      16.heightBox,
                      GFButton(
                        size: 60,
                        fullWidthButton: true,
                        onPressed: () => state.createReview(context),
                        text: 'REVIEW',
                        type: GFButtonType.solid,
                        color: context.primaryColor,
                      ),
                      16.heightBox,
                    ],
                  ),
                ).p8(),
              ),
            ),
          ),
        );
      },
    );
  }
}
