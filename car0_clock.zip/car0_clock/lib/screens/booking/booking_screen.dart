import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:v1techx/v1techx.dart';

class BookingScreen extends StatelessWidget {
  final Service service;

  const BookingScreen({
    Key? key,
    required this.service,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<BookingState>(
      onStateReady: (state) {
        state.init(service);
      },
      create: (context, state, child) {
        return Scaffold(
          body: _body(context, state),
        );
      },
    );
  }

  Widget _body(BuildContext context, BookingState state) {
    if (state.isBusy) return GFLoader();

    return LoadingOverlay(
      isLoading: state.isNestedBusy,
      child: Column(
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    ProgressImage(
                      url: state.service.image,
                      height: 300,
                      width: context.width,
                      fit: BoxFit.cover,
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: CloseButton(color: Colors.white),
                    ).p8().safeArea(),
                  ],
                ),
                16.heightBox,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        state.service.name.text.bold.make().expand(),
                        Row(
                          children: [
                            Icon(Icons.timer, size: 18),
                            4.widthBox,
                            state.service.time.text.make(),
                          ],
                        ),
                      ],
                    ),
                    8.heightBox,
                    Row(
                      children: [
                        RatingBar.builder(
                          initialRating: state.service.rating.toDouble(),
                          minRating: 1,
                          direction: Axis.horizontal,
                          allowHalfRating: true,
                          itemCount: 5,
                          itemSize: 14,
                          itemBuilder: (context, _) => Icon(
                            Icons.star,
                            color: context.primaryColor,
                          ),
                          onRatingUpdate: (double value) {},
                        ),
                        4.widthBox,
                        '(${state.service.review} ratings)'
                            .text
                            .caption(context)
                            .make(),
                      ],
                    ),
                    8.heightBox,
                    '${state.settings.symbol}${state.service.price}'
                        .text
                        .semiBold
                        .size(24)
                        .color(context.primaryColor)
                        .make()
                        .hide(isVisible: !state.service.onInspection),
                    4.heightBox,
                  ],
                ).px8(),
                16.heightBox,
                Divider(),
                HtmlWidget(state.service.description).px8(),
                8.heightBox,
              ],
            ),
          ).expand(),
          GFButton(
            onPressed: () => state.openQuestion(context),
            shape: GFButtonShape.square,
            fullWidthButton: true,
            child: 'Book This Service'.text.bold.make(),
          ).h(60),
        ],
      ),
    );
  }
}
