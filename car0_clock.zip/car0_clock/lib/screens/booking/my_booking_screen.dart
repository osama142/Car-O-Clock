import 'package:car_detailing/screens/widgets/authentication_error.dart';
import 'package:car_detailing/screens/widgets/empty.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class MyBookingScreen extends StatelessWidget {
  const MyBookingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<MyBookingState>(
      onStateReady: (state) => state.getBookings(),
      create: (context, state, child) {
        if (!state.auth.isLoggedIn) {
          return Scaffold(
            appBar: AppBar(
              title: 'My Bookings'.text.make(),
            ),
            body: AuthenticationError(
              subtitle: 'booking history',
              onPressed: () => state.openAuthScreen(context),
            ),
          );
        }

        return Scaffold(
          appBar: AppBar(
            title: 'My Bookings'.text.make(),
          ),
          body: _body(context, state),
        );
      },
    );
  }

  Widget _body(BuildContext context, MyBookingState state) {
    if (state.isBusy) return GFLoader();

    if (state.bookings.isEmpty) return Empty(subtitle: 'Previous Bookings');

    return ListView.separated(
      itemCount: state.bookings.length,
      separatorBuilder: (_, __) => 16.heightBox,
      itemBuilder: (_, int index) {
        final item = state.bookings[index];

        return Container(
          color: Colors.white,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network(
                item.service.image,
                height: 50,
                width: 50,
                fit: BoxFit.cover,
              ),
              16.widthBox,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  item.service.name.text.bold.make(),
                  16.heightBox,
                  Row(
                    children: [
                      _Status(status: item.status).expand(),
                      Row(
                        children: [
                          Icon(Icons.date_range, size: 18),
                          4.widthBox,
                          '${parseDate(item.date)}'.text.make(),
                        ],
                      ),
                    ],
                  ),
                ],
              ).expand(),
            ],
          ).p16(),
        ).onInkTap(() => state.router.toBookingDetailsScreen(context, item));
      },
    );
  }
}

class _Status extends StatelessWidget {
  final String status;

  const _Status({
    Key? key,
    required this.status,
  }) : super(key: key);

  Color _statusColor() {
    if (status == 'pending') return Colors.grey.shade800;

    if (status == 'cancelled') return Colors.red.shade800;

    if (status == 'confirmed') return Colors.blue.shade800;

    return Colors.green.shade800;
  }

  @override
  Widget build(BuildContext context) {
    return status.text.xs.semiBold.uppercase.color(_statusColor()).make();
  }
}
