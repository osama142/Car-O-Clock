import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class SuccessScreen extends StatelessWidget {
  const SuccessScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<SuccessState>(
      create: (context, state, child) {
        return Scaffold(
          backgroundColor: Colors.white,
          body: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                Assets.imgSuccess,
                height: 128,
                width: 128,
              ),
              16.heightBox,
              'Successful !!'.text.bold.make(),
              16.heightBox,
              'Your payment was done successfully'.text.caption(context).make(),
              32.heightBox,
              GFButton(
                onPressed: () => state.router.toMyBookingScreen(
                  context,
                  replace: true,
                ),
                fullWidthButton: true,
                shape: GFButtonShape.pills,
                child: 'MY BOOKINGS'.text.make(),
              ).px24(),
            ],
          ).centered(),
        );
      },
    );
  }
}
