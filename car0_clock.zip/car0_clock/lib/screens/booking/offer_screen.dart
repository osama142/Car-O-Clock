import 'package:car_detailing/models/models.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class OfferScreen extends StatelessWidget {
  final List<Offer> offers;

  const OfferScreen({
    Key? key,
    required this.offers,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: 'Offers'.text.make(),
      ),
      body: ListView.separated(
        itemCount: offers.length,
        separatorBuilder: (_, __) => 16.heightBox,
        itemBuilder: (_, int index) {
          final item = offers[index];

          return _OfferItem(
            item: item,
            onPress: () => context.pop(item),
          );
        },
      ),
    );
  }
}

class _OfferItem extends StatelessWidget {
  final Offer item;
  final VoidCallback onPress;

  const _OfferItem({
    Key? key,
    required this.item,
    required this.onPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade400),
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              item.title.text.bold.xl2.make(),
              16.heightBox,
              item.description.text.caption(context).make(),
              16.heightBox.hide(isVisible: item.minimumAmount > 0),
              'MINIMUM AMOUNT: ${item.minimumAmount}'
                  .text
                  .bodyText2(context)
                  .make()
                  .hide(isVisible: item.minimumAmount > 0),
              16.heightBox,
              GFButton(
                onPressed: onPress,
                shape: GFButtonShape.pills,
                child: 'APPLY'.text.make(),
              ),
            ],
          ).expand(),
          Image.network(
            item.image,
            fit: BoxFit.cover,
            height: 100,
            width: 100,
          ),
        ],
      ).p16(),
    ).p8();
  }
}
