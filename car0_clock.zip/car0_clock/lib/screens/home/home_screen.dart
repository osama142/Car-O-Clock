import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/screens/main/main_drawer.dart';
import 'package:car_detailing/states/states.dart';
import 'package:car_detailing/widgets/grid_list.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:v1techx/v1techx.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<HomeState>(
      onStateReady: (state) => state.getCategory(),
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(
            centerTitle: true,
            title: Image.asset(
              Assets.logoIcon,
              height: 40,
              width: 40,
            ),
            actions: [
              IconButton(
                onPressed: () => state.openAccount(context),
                icon: Icon(Icons.account_circle_outlined),
              ),
            ],
          ),
          drawer: MainDrawer(state: state),
          body: Stack(
            children: [
              ClipPath(
                clipper: OvalBottomBorderClipper(),
                child: Container(
                  color: context.primaryColor,
                  height: 150,
                ),
              ),
              _body(context, state),
            ],
          ),
        );
      },
    );
  }

  Widget _body(BuildContext context, HomeState state) {
    if (state.isBusy) return GFLoader();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CarouselSlider(
            items: state.images,
            options: CarouselOptions(
              viewportFraction: 0.9,
              initialPage: 0,
              enableInfiniteScroll: true,
              autoPlay: true,
              enlargeCenterPage: false,
              scrollDirection: Axis.horizontal,
            ),
          ),
          8.heightBox,
          Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                8.heightBox,
                'PLEASE SELECT A SERVICE'
                    .text
                    .bold
                    .color(context.primaryColor)
                    .make(),
                32.heightBox,
                GridList(
                  itemCount: state.categories.length,
                  padding: EdgeInsets.zero,
                  cellHeight: 120,
                  crossAxisCount: 3,
                  mainAxisSpacing: 1,
                  crossAxisSpacing: 1,
                  itemBuilder: (BuildContext context, int index) {
                    final item = state.categories[index];

                    return _CategoryItem(item: item).onInkTap(
                        () => state.openServiceOrServices(context, item));
                  },
                ),
              ],
            ).p16(),
          ),
          16.heightBox,
        ],
      ).p16(),
    );
  }
}

class _CategoryItem extends StatelessWidget {
  final Category item;

  const _CategoryItem({
    Key? key,
    required this.item,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: item.image != null
              ? Image.network(
                  item.image ?? '',
                  height: 65,
                  width: 65,
                  fit: BoxFit.cover,
                )
              : Image(
                  image: Assets.imgBlank,
                  height: 65,
                  width: 65,
                  fit: BoxFit.cover,
                ),
        ),
        8.heightBox,
        item.title.text.caption(context).semiBold.make(),
      ],
    );
  }
}
