import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/screens/widgets/empty.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:v1techx/v1techx.dart';

class ServiceDetailsScreen extends StatelessWidget {
  final Category category;

  const ServiceDetailsScreen({
    Key? key,
    required this.category,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<ServiceDetailsState>(
      onStateReady: (state) {
        state.getCategory(category);
      },
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(
            title: 'Service Details'.text.make(),
          ),
          body: _body(context, state),
        );
      },
    );
  }

  Widget _body(BuildContext context, ServiceDetailsState state) {
    if (state.isBusy) return GFLoader();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListView.separated(
          itemCount: state.categories.length,
          scrollDirection: Axis.horizontal,
          separatorBuilder: (_, __) => 16.widthBox,
          itemBuilder: (_, int index) {
            final item = state.categories[index];

            return _SubcategoryItem(
              item: item,
              onPressed: () => state.sort(item),
            );
          },
        ).h(100).hide(isVisible: state.categories.isNotEmpty),
        16.heightBox.hide(isVisible: state.categories.isNotEmpty),
        'Services'
            .text
            .bold
            .color(context.primaryColor)
            .make()
            .hide(isVisible: state.categories.isNotEmpty),
        8.heightBox.hide(isVisible: state.categories.isNotEmpty),
        Empty(subtitle: 'Service')
            .centered()
            .hide(isVisible: state.sortedServices.isEmpty),
        ListView.separated(
          itemCount: state.sortedServices.length,
          separatorBuilder: (_, __) => 8.heightBox,
          itemBuilder: (_, int index) {
            final item = state.sortedServices[index];

            return _ServiceItem(
              item: item,
              symbol: state.settings.symbol,
              onPressed: () => state.openBookingScreen(context, item),
            ).onInkTap(() => state.openBookingScreen(context, item));
          },
        ).expand().hide(isVisible: state.services.isNotEmpty),
        8.heightBox.hide(isVisible: state.categories.isNotEmpty),
      ],
    ).p8();
  }
}

class _SubcategoryItem extends StatelessWidget {
  final Category item;
  final VoidCallback onPressed;

  const _SubcategoryItem({
    Key? key,
    required this.item,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          decoration: item.selected
              ? BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: context.primaryColor,
                  ),
                )
              : null,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: item.image != null
                ? Image(
                    image: NetworkImage(item.image!),
                    height: 65,
                    width: 65,
                    fit: BoxFit.cover,
                  )
                : Image(
                    image: Assets.imgBlank,
                    height: 65,
                    width: 65,
                    fit: BoxFit.cover,
                  ),
          ).p4(),
        ),
        8.heightBox,
        item.title.text.caption(context).semiBold.make(),
      ],
    ).onInkTap(onPressed);
  }
}

class _ServiceItem extends StatelessWidget {
  final Service item;
  final String symbol;
  final VoidCallback onPressed;

  const _ServiceItem({
    Key? key,
    required this.item,
    required this.symbol,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(12),
              topRight: Radius.circular(12),
            ),
            child: Image.network(
              item.image,
              height: 140,
              width: context.width,
              fit: BoxFit.cover,
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                children: [
                  item.name.text.bold.make().expand(),
                  Row(
                    children: [
                      Icon(Icons.timer, size: 18),
                      4.widthBox,
                      item.time.text.make(),
                    ],
                  ),
                ],
              ),
              8.heightBox,
              Row(
                children: [
                  RatingBar.builder(
                    initialRating: item.rating.toDouble(),
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 5,
                    itemSize: 14,
                    itemBuilder: (context, _) => Icon(
                      Icons.star,
                      color: context.primaryColor,
                    ),
                    onRatingUpdate: (double value) {},
                  ),
                  4.widthBox,
                  '(${item.review} ratings)'.text.caption(context).make(),
                ],
              ),
              8.heightBox,
              Row(
                children: [
                  GFButton(
                    onPressed: onPressed,
                    shape: GFButtonShape.pills,
                    child: 'BOOK'.text.make(),
                  ),
                  Spacer(),
                  '$symbol${item.price}'
                      .text
                      .semiBold
                      .size(24)
                      .color(context.primaryColor)
                      .make()
                      .hide(isVisible: !item.onInspection),
                ],
              ),
              4.heightBox,
            ],
          ).p16(),
        ],
      ),
    );
  }
}
