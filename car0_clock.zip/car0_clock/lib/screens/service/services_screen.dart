import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<ServicesState>(
      onStateReady: (state) {
        state.getCategory();
      },
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(
            title: 'Services'.text.make(),
          ),
          body: _body(context, state),
        );
      },
    );
  }

  Widget _body(BuildContext context, ServicesState state) {
    if (state.isBusy) return GFLoader();

    return ListView.separated(
      itemCount: state.categories.length,
      separatorBuilder: (_, __) => Divider(),
      itemBuilder: (_, int index) {
        final item = state.categories[index];

        return ListTile(
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: item.image != null
                ? Image.network(
                    item.image ?? '',
                    height: 70,
                    width: 70,
                  ).p8()
                : Image(
                    image: Assets.imgBlank,
                    height: 70,
                    width: 70,
                  ).p8(),
          ),
          title: item.title.text.make(),
          onTap: () => state.openService(context, item),
        );
      },
    );
  }
}
