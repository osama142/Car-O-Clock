import 'package:car_detailing/states/states.dart';
import 'package:car_detailing/theme/style.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

import 'auth_header.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<RegisterState>(
      create: (context, state, child) {
        return Scaffold(
          backgroundColor: Colors.grey.shade50,
          body: LoadingOverlay(
            isLoading: state.isBusy,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  AuthHeader(title: 'REGISTER'),
                  (context.percentHeight * 10).heightBox,
                  'Please register to continue'.text.bodyText1(context).make(),
                  32.heightBox,
                  _registerForm(state),
                  16.heightBox,
                  Hero(
                    tag: 'auth-register',
                    child: GFButton(
                      elevation: 4,
                      color: context.primaryColor,
                      shape: GFButtonShape.pills,
                      fullWidthButton: true,
                      onPressed: () => state.register(context),
                      child: 'REGISTER'.text.bold.make(),
                    ).h(40).px16(),
                  ),
                  GFButton(
                    type: GFButtonType.transparent,
                    onPressed: () => state.haveAnAccount(context),
                    child: 'Already Have An Account? Login Here'.text.make(),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _registerForm(RegisterState state) {
    return Form(
      key: state.registerForm,
      child: Column(
        children: [
          TextFormField(
            controller: state.nameController,
            keyboardType: TextInputType.name,
            validator: requiredValidator,
            textCapitalization: TextCapitalization.words,
            decoration: inputDecoration('Name'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.emailController,
            keyboardType: TextInputType.emailAddress,
            validator: validator.email().build(),
            decoration: inputDecoration('Email'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.mobileController,
            keyboardType: TextInputType.phone,
            validator: validator.phone().build(),
            decoration: inputDecoration('Mobile'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.passwordController,
            validator: requiredValidator,
            obscureText: true,
            decoration: inputDecoration('Password'),
          ),
        ],
      ),
    ).px16();
  }
}
