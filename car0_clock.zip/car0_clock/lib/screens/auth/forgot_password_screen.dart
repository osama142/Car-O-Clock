import 'package:car_detailing/states/states.dart';
import 'package:car_detailing/theme/style.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

import 'auth_header.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<ForgotState>(
      create: (context, state, child) {
        return Scaffold(
          backgroundColor: Colors.grey.shade50,
          body: LoadingOverlay(
            isLoading: state.isBusy,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    children: [
                      AuthHeader(title: 'RESET PASSWORD'),
                      CloseButton().safeArea(),
                    ],
                  ),
                  (context.percentHeight * 10).heightBox,
                  'Please enter your email'.text.bodyText1(context).make(),
                  32.heightBox,
                  _forgotForm(context, state),
                  16.heightBox,
                  Hero(
                    tag: 'auth-login',
                    child: GFButton(
                      elevation: 4,
                      color: context.primaryColor,
                      shape: GFButtonShape.pills,
                      fullWidthButton: true,
                      onPressed: () => state.sendResetEmail(context),
                      child: 'RESET'.text.bold.make(),
                    ).h(40).px16(),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _forgotForm(BuildContext context, ForgotState state) {
    return Form(
      key: state.loginForm,
      child: Column(
        children: [
          TextFormField(
            controller: state.emailController,
            keyboardType: TextInputType.emailAddress,
            validator: validator.email().build(),
            decoration: inputDecoration('Email'),
          ),
        ],
      ),
    ).px16();
  }
}
