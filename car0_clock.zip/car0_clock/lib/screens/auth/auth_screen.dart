import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<AuthState>(
      create: (context, state, child) {
        return Scaffold(
          body: SafeArea(
            child: Column(
              children: [
                32.heightBox,
                'WELCOME TO V1 CAR DETAILING'
                    .text
                    .bold
                    .xl2
                    .color(context.primaryColor)
                    .make(),
                Spacer(),
                Hero(
                  tag: 'auth-logo',
                  child: Image.asset(
                    Assets.logoIcon,
                    height: 150,
                    width: 150,
                  ),
                ),
                Spacer(),
                Hero(
                  tag: 'auth-login',
                  child: GFButton(
                    onPressed: () => state.login(context),
                    fullWidthButton: true,
                    color: context.primaryColor,
                    shape: GFButtonShape.pills,
                    type: GFButtonType.outline,
                    child: 'LOGIN'.text.make(),
                  ).h(50),
                ),
                12.heightBox,
                Hero(
                  tag: 'auth-register',
                  child: GFButton(
                    onPressed: () => state.register(context),
                    fullWidthButton: true,
                    color: context.primaryColor,
                    shape: GFButtonShape.pills,
                    child: 'REGISTER'.text.make(),
                  ).h(50),
                ),
                GFButton(
                  onPressed: () => state.skip(context),
                  type: GFButtonType.transparent,
                  child:
                      'SKIP FOR NOW'.text.xs.color(context.primaryColor).make(),
                ),
              ],
            ).p16(),
          ),
        );
      },
    );
  }
}
