import 'package:car_detailing/screens/auth/auth_header.dart';
import 'package:car_detailing/states/states.dart';
import 'package:car_detailing/theme/style.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<LoginState>(
      create: (context, state, child) {
        return Scaffold(
          backgroundColor: Colors.grey.shade50,
          body: LoadingOverlay(
            isLoading: state.isBusy,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  AuthHeader(title: 'LOGIN'),
                  (context.percentHeight * 10).heightBox,
                  'Please login to continue'.text.bodyText1(context).make(),
                  32.heightBox,
                  _loginForm(context, state),
                  16.heightBox,
                  Hero(
                    tag: 'auth-login',
                    child: GFButton(
                      elevation: 4,
                      color: context.primaryColor,
                      shape: GFButtonShape.pills,
                      fullWidthButton: true,
                      onPressed: () => state.login(context),
                      child: 'LOGIN'.text.bold.make(),
                    ).h(40).px16(),
                  ),
                  GFButton(
                    type: GFButtonType.transparent,
                    onPressed: () => state.haveAnAccount(context),
                    child: 'Don\'t have an account? Register here'.text.make(),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _loginForm(BuildContext context, LoginState state) {
    return Form(
      key: state.loginForm,
      child: Column(
        children: [
          TextFormField(
            controller: state.emailController,
            keyboardType: TextInputType.emailAddress,
            validator: validator.email().build(),
            decoration: inputDecoration('Email'),
          ),
          16.heightBox,
          TextFormField(
            controller: state.passwordController,
            validator: requiredValidator,
            obscureText: true,
            decoration: inputDecoration('Password'),
          ),
          GFButton(
            type: GFButtonType.transparent,
            onPressed: () => state.forgot(context),
            child: 'Forgot Password?'.text.make(),
          ).objectCenterRight(),
        ],
      ),
    ).px16();
  }
}
