import 'package:car_detailing/commons/commons.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:v1techx/v1techx.dart';

class AuthHeader extends StatelessWidget {
  final String title;

  const AuthHeader({
    Key? key,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        ClipPath(
          clipper: OvalBottomBorderClipper(),
          child: Container(
            width: context.width,
            height: 160,
            color: context.primaryColor,
            alignment: Alignment.topCenter,
            child: title.text.xl2.bold.white.make().safeArea().py32(),
          ),
        ),
        Positioned(
          bottom: -50,
          left: (context.width / 2) - 60,
          child: Hero(
            tag: 'auth-logo',
            child: Image.asset(
              Assets.logoIcon,
              fit: BoxFit.cover,
              height: 120,
              width: 120,
            ),
          ),
        ),
      ],
    );
  }
}
