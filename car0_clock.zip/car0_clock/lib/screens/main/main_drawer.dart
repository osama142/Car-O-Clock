import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:v1techx/v1techx.dart';

class MainDrawer extends StatelessWidget {
  final HomeState state;

  const MainDrawer({
    Key? key,
    required this.state,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Stack(
            children: [
              ClipPath(
                clipper: DiagonalPathClipperOne(),
                child: Container(
                  height: 130,
                  color: context.primaryColor,
                ),
              ),
              Positioned(
                bottom: -10,
                left: (304 / 2) - 50,
                child: Image.asset(
                  Assets.logoIcon,
                  height: 100,
                  width: 100,
                ),
              ),
            ],
          ),
          ListTile(
            leading: ImageIcon(AssetImage(Assets.iconBookNow)),
            title: 'Book Now'.text.make(),
            onTap: () => state.onDrawerChange(context, 0),
          ),
          ListTile(
            leading: ImageIcon(AssetImage(Assets.iconMyBooking)),
            title: 'My Bookings'.text.make(),
            onTap: () {
              context.pop();
              state.router.toMyBookingScreen(context);
            },
          ),
          ListTile(
            leading: Icon(LineIcons.user),
            title: 'My Account'.text.make(),
            onTap: () {
              context.pop();
              state.router.toAccountScreen(context);
            },
          ),
          // Divider(),
          // ListTile(
          //   leading: Icon(Icons.rate_review_outlined),
          //   title: 'Reviews & Feedback'.text.make(),
          //   onTap: () {
          //     context.pop();
          //     state.router.toReviewScreen(context);
          //   },
          // ),
          ListTile(
            leading: Icon(LineIcons.info),
            title: 'Help & Info'.text.make(),
            onTap: () {
              context.pop();
              state.router.toHelpScreen(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.star_border_outlined),
            title: 'Rate App'.text.make(),
            onTap: () {
              context.pop();
              state.review();
            },
          ),
          ListTile(
            leading: Icon(LineIcons.share),
            title: 'Share App'.text.make(),
            onTap: () {
              context.pop();
              state.share();
            },
          ),
          ListTile(
            leading: Icon(LineIcons.phone),
            title: 'Contact Us'.text.make(),
            onTap: () {
              context.pop();
              state.router.toContactScreen(context);
            },
          ),
        ],
      ),
    );
  }
}
