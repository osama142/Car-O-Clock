import 'package:bottom_navy_bar/bottom_navy_bar.dart';
import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<MainState>(
      create: (context, state, child) {
        return Scaffold(
          bottomNavigationBar: BottomNavyBar(
            showElevation: true,
            selectedIndex: state.drawer.currentIndex,
            onItemSelected: state.onPageChange,
            items: [
              BottomNavyBarItem(
                icon: ImageIcon(AssetImage(Assets.iconBookNow)),
                title: Text('Book Now'),
                activeColor: Colors.red,
              ),
              BottomNavyBarItem(
                icon: ImageIcon(AssetImage(Assets.iconMyBooking)),
                title: Text('Bookings'),
                activeColor: Colors.purpleAccent,
              ),
              BottomNavyBarItem(
                icon: Icon(Icons.person),
                title: Text('Account'),
                activeColor: Colors.pink,
              ),
              BottomNavyBarItem(
                icon: Icon(Icons.apps),
                title: Text('More'),
                activeColor: Colors.blue,
              ),
            ],
          ),
          body: state.screens[state.drawer.currentIndex],
        );
      },
    );
  }
}
