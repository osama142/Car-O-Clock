import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<SplashState>(
      onStateReady: (state) => state.init(context),
      create: (context, state, child) {
        return Scaffold(
          body: Image.asset(
            Assets.splash,
            fit: BoxFit.cover,
            width: context.width,
            height: context.height,
          ),
        );
      },
    );
  }
}
