import 'package:car_detailing/states/states.dart';
import 'package:car_detailing/theme/style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:v1techx/v1techx.dart';

class ReviewScreen extends StatelessWidget {
  const ReviewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<ReviewState>(
      onStateReady: (state) => state.init(),
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(
            title: 'Review'.text.make(),
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: MediaQuery.of(context).viewInsets,
              child: Form(
                key: state.form,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(
                      controller: state.nameController,
                      textCapitalization: TextCapitalization.words,
                      validator: requiredValidator,
                      decoration: contactInputDecoration('Name', Icons.person),
                    ),
                    16.heightBox,
                    TextFormField(
                      controller: state.phoneController,
                      keyboardType: TextInputType.phone,
                      validator: validator.phone().build(),
                      decoration: contactInputDecoration('Phone', Icons.phone),
                    ),
                    16.heightBox,
                    TextFormField(
                      controller: state.emailController,
                      keyboardType: TextInputType.emailAddress,
                      validator: validator.email().build(),
                      decoration: contactInputDecoration('Email', Icons.email),
                    ),
                    16.heightBox,
                    TextFormField(
                      controller: state.reviewController,
                      validator: requiredValidator,
                      textAlign: TextAlign.justify,
                      maxLines: 3,
                      decoration:
                          contactInputDecoration('Review', Icons.message),
                    ),
                    16.heightBox,
                    'Rating'.text.semiBold.make().px4(),
                    RatingBar.builder(
                      initialRating: state.rating,
                      minRating: 1,
                      direction: Axis.horizontal,
                      allowHalfRating: true,
                      itemCount: 5,
                      itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                      itemBuilder: (context, _) => Icon(
                        Icons.star,
                        color: context.primaryColor,
                      ),
                      onRatingUpdate: state.updateRating,
                    ),
                    16.heightBox,
                    GFButton(
                      size: 60,
                      fullWidthButton: true,
                      onPressed: () => state.review(context),
                      text: 'REVIEW',
                      type: GFButtonType.solid,
                      color: context.primaryColor,
                    ),
                    16.heightBox,
                  ],
                ),
              ).p8(),
            ),
          ),
        );
      },
    );
  }
}
