import 'package:car_detailing/states/states.dart';
import 'package:contactus/contactus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:v1techx/v1techx.dart';

class ContactUsScreen extends StatelessWidget {
  const ContactUsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<ContactState>(
      onStateReady: (state) => state.init(),
      create: (BuildContext context, state, child) {
        return Scaffold(
          appBar: AppBar(),
          body: _body(context, state),
        );
      },
    );
  }

  Widget _body(BuildContext context, ContactState state) {
    if (state.isBusy) return GFLoader();

    return Stack(
      children: [
        ClipPath(
          clipper: MultipleRoundedCurveClipper(),
          child: Container(
            color: context.primaryColor,
            height: 80,
            width: context.screenWidth,
          ),
        ),
        ListView(
          children: [
            ContactUs(
              dividerThickness: 2,
              textColor: context.primaryColor,
              cardColor: Colors.white,
              companyColor: Colors.white,
              taglineColor: Colors.red,
              dividerColor: Colors.transparent,
              companyName: 'Contact Us',
              phoneNumberText: state.findLink('phone'),
              emailText: state.findLink('email'),
              websiteText: state.findLink('website'),
              email: state.findLink('email'),
              phoneNumber: state.findLink('phone'),
              website: state.findLink('website'),
              linkedinURL: state.findLink('linkedin'),
              twitterHandle: state.findLink('twitter'),
              facebookHandle: state.findLink('facebook'),
            ),
            8.heightBox,
            GFButton(
              size: 50,
              fullWidthButton: true,
              onPressed: () => state.openEnquiryDialog(context),
              text: 'Send us a message',
              type: GFButtonType.solid,
              shape: GFButtonShape.pills,
              color: context.primaryColor,
            ).px(28),
          ],
        ),
      ],
    );
  }
}
