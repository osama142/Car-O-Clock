import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Content<HelpState>(
      onStateReady: (state) => state.getCommon(),
      create: (context, state, child) {
        return Scaffold(
          appBar: AppBar(
            title: 'Help'.text.make(),
          ),
          body: _body(context, state),
        );
      },
    );
  }

  Widget _body(BuildContext context, HelpState state) {
    if (state.isBusy) return GFLoader();

    return Column(
      children: [
        ListTile(
          leading: Icon(Icons.question_answer),
          title: 'FAQ'.text.make(),
          trailing: Icon(Icons.arrow_forward_ios),
          onTap: () => state.router.toFaqScreen(
            context,
            state.common.faqs,
          ),
        ),
        ListTile(
          leading: Icon(Icons.reduce_capacity_sharp),
          title: 'Terms & Condition'.text.make(),
          trailing: Icon(Icons.arrow_forward_ios),
          onTap: () => state.router.toHtmlScreen(
            context,
            'Terms & Condition',
            state.common.terms,
          ),
        ),
        ListTile(
          leading: Icon(Icons.lock),
          title: 'Privacy Policy'.text.make(),
          trailing: Icon(Icons.arrow_forward_ios),
          onTap: () => state.router.toHtmlScreen(
            context,
            'Privacy Policy',
            state.common.privacy,
          ),
        ),
      ],
    );
  }
}
