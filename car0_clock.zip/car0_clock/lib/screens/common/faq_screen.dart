import 'package:car_detailing/models/models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:v1techx/v1techx.dart';

class FaqScreen extends StatelessWidget {
  final List<Faq> faqs;

  const FaqScreen({
    Key? key,
    required this.faqs,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: ListView.separated(
        shrinkWrap: true,
        primary: false,
        itemCount: faqs.length,
        separatorBuilder: (_, __) => Divider(),
        itemBuilder: (_, int index) => _FAQItem(faq: faqs[index]),
      ),
    );
  }
}

class _FAQItem extends StatelessWidget {
  final Faq faq;

  _FAQItem({required this.faq});

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      key: UniqueKey(),
      title: faq.title.text.make(),
      children: [
        HtmlWidget(
          faq.description,
          webView: true,
          buildAsync: true,
        ).p16(),
      ],
    );
  }
}
