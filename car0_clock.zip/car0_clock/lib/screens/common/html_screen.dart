import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:v1techx/v1techx.dart';

class HTMLScreen extends StatelessWidget {
  final String title;
  final String data;

  const HTMLScreen({
    Key? key,
    required this.title,
    required this.data,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: title.text.make(),
      ),
      body: SingleChildScrollView(
        child: HtmlWidget(data).p8(),
      ),
    );
  }
}
