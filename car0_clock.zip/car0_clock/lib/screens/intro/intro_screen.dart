import 'package:car_detailing/states/states.dart';
import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:v1techx/v1techx.dart';

class IntroScreen extends StatefulWidget {
  const IntroScreen({Key? key}) : super(key: key);

  @override
  _IntroScreenState createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  @override
  Widget build(BuildContext context) {
    return Content<IntroState>(
      create: (context, state, child) {
        return Scaffold(
          body: IntroductionScreen(
            pages: state.pages(),
            showNextButton: false,
            showSkipButton: true,
            skip: 'Skip'.text.make(),
            done: 'Done'.text.make(),
            onDone: () => state.onDone(context),
            onSkip: () => state.onDone(context),
          ),
        );
      },
    );
  }
}
