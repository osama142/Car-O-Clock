import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:car_detailing/theme/style.dart';
import 'package:flutter/material.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:v1techx/v1techx.dart';

class ContactState extends ViewModel {
  late Common common;

  final form = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final emailController = TextEditingController();
  final messageController = TextEditingController();

  void init() {
    getCommon();

    if (!auth.isLoggedIn) return;

    final user = auth.user!;

    nameController.text = user.name;
    phoneController.text = user.mobile;
    emailController.text = user.email;
  }

  void getCommon() async {
    try {
      setBusy(true);
      common = await api.common();
      setBusy(false);
    } catch (e) {
      setBusy(false);
    }
  }

  void contact(BuildContext context) async {
    if (!form.currentState!.validate()) return;

    context.pop();

    try {
      setBusy(true);
      final data = {
        'name': nameController.text,
        'phone': phoneController.text,
        'email': emailController.text,
        'query': messageController.text,
      };

      await api.contact(data);
      setBusy(false);
      alert!.success(
        context: context,
        title:
            'Thanks for contacting us. One of us will get back to you at the earliest.',
        label: 'OK',
      );
    } catch (e) {
      setBusy(false);
      alert!.error(
        context: context,
        title: e.toString(),
      );
    }
  }

  void openEnquiryDialog(BuildContext context) {
    showMaterialModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      builder: (_) {
        return SingleChildScrollView(
          controller: ModalScrollController.of(context),
          child: Padding(
            padding: MediaQuery.of(context).viewInsets,
            child: Form(
              key: form,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  'Submit Your Query'.text.bold.make().p8(),
                  Divider(),
                  TextFormField(
                    controller: nameController,
                    textCapitalization: TextCapitalization.words,
                    validator: requiredValidator,
                    decoration: contactInputDecoration('Name', Icons.person),
                  ),
                  16.heightBox,
                  TextFormField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    validator: validator.phone().build(),
                    decoration: contactInputDecoration('Phone', Icons.phone),
                  ),
                  16.heightBox,
                  TextFormField(
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    validator: validator.email().build(),
                    decoration: contactInputDecoration('Email', Icons.email),
                  ),
                  16.heightBox,
                  TextFormField(
                    controller: messageController,
                    validator: requiredValidator,
                    textAlign: TextAlign.justify,
                    maxLines: 3,
                    decoration: contactInputDecoration('Query', Icons.message),
                  ),
                  16.heightBox,
                  GFButton(
                    size: 60,
                    fullWidthButton: true,
                    onPressed: () => contact(context),
                    text: 'ENQUIRY',
                    type: GFButtonType.solid,
                    color: context.primaryColor,
                  ),
                  16.heightBox,
                ],
              ),
            ).p8(),
          ),
        );
      },
    );
  }

  String findLink(String title) {
    final data = common.links;
    final index = data.indexWhere((element) => element.title == title);

    if (index == -1) return '';

    return data[index].value ?? '';
  }
}
