import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';

class HelpState extends ViewModel {
  late Common common;

  void getCommon() async {
    try {
      setBusy(true);
      common = await api.common();
      setBusy(false);
    } catch (e) {
      setBusy(false);
    }
  }
}
