import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class ReviewState extends ViewModel {
  final form = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final reviewController = TextEditingController();

  double rating = 0;

  void init() {
    if (!auth.isLoggedIn) return;

    final user = auth.user!;

    nameController.text = user.name;
    phoneController.text = user.mobile;
    emailController.text = user.email;
  }

  void updateRating(double value) {
    rating = value;
  }

  void review(BuildContext context) async {
    if (!form.currentState!.validate()) return;

    try {
      setBusy(true);

      final data = {
        'name': nameController.text,
        'phone': phoneController.text,
        'email': emailController.text,
        'rating': rating,
        'review': reviewController.text,
      };

      await api.review(data);
      setBusy(false);

      alert!.success(
        context: context,
        title: 'Thank You For Your Feedback!',
      );
    } catch (e) {
      setBusy(false);
      alert!.error(
        context: context,
        title: e.toString(),
      );
    }
  }
}
