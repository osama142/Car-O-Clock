import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';

class AuthState extends ViewModel {
  void skip(BuildContext context) {
    pref.setAuthStatus(true);
    router.toMainScreen(context);
  }

  void login(BuildContext context) {
    router.toLoginScreen(context);
  }

  void register(BuildContext context) {
    router.toRegisterScreen(context);
  }
}
