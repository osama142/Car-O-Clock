import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class ForgotState extends ViewModel {
  final loginForm = GlobalKey<FormState>();

  final emailController = TextEditingController();

  void sendResetEmail(BuildContext context) async {
    if (!loginForm.currentState!.validate()) return;

    try {
      setBusy(true);
      await api.forgot({'email': emailController.text});
      setBusy(false);

      alert!.success(context: context, title: 'Please check your email!');
    } catch (e) {
      setBusy(false);
      alert!.error(context: context, title: e.toString());
    }
  }
}
