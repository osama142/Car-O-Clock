import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class LoginState extends ViewModel {
  final loginForm = GlobalKey<FormState>();

  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  Future login(BuildContext context) async {
    if (!loginForm.currentState!.validate()) return;

    final data = {
      'email': emailController.text,
      'password': passwordController.text,
    };

    try {
      setBusy(true);
      final response = await api.login(data);
      await auth.setResponse(response);
      setBusy(false);

      router.toMainScreen(context);
    } catch (e) {
      setBusy(false);
      alert!.error(
        context: context,
        title: 'Error',
        desc: e.toString(),
      );
    }
  }

  void forgot(BuildContext context) => router.toForgotScreen(context);

  void haveAnAccount(BuildContext context) {
    router.toRegisterScreen(context, replace: true);
  }
}
