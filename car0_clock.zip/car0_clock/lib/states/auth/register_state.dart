import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class RegisterState extends ViewModel {
  final registerForm = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final mobileController = TextEditingController();
  final passwordController = TextEditingController();

  void register(BuildContext context) async {
    if (!registerForm.currentState!.validate()) return;

    final data = {
      'name': nameController.text,
      'email': emailController.text,
      'mobile': mobileController.text,
      'password': passwordController.text,
    };

    try {
      setBusy(true);
      final response = await api.register(data);
      await auth.setResponse(response);
      setBusy(false);

      router.toMainScreen(context);
    } catch (e) {
      setBusy(false);
      alert!.error(
        context: context,
        title: 'Error',
        desc: e.toString(),
      );
    }
  }

  void haveAnAccount(BuildContext context) {
    router.toLoginScreen(context, replace: true);
  }
}
