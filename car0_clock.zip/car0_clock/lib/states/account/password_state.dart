import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class PasswordState extends ViewModel {
  final form = GlobalKey<FormState>();

  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  void update(BuildContext context) async {
    if (!form.currentState!.validate()) return;

    setBusy(true);
    final data = {'password': passwordController.text};

    try {
      setBusy(true);
      final response = await api.profile(auth.user!.id, data);
      await auth.setResponse(response);
      setBusy(false);

      alert!.success(
        context: context,
        title: 'Password Changed Successfully!',
      );
    } catch (e) {
      setBusy(false);
      alert!.error(
        context: context,
        title: 'Error',
        desc: e.toString(),
      );
    }

    setBusy(false);
  }

  String? sameValidate(value) {
    if (passwordController.text != confirmPasswordController.text) {
      return 'Password does not match';
    }

    return null;
  }

  User get user => auth.user!;
}
