import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';

class AllReviewState extends ViewModel {
  List<Review> reviews = [];

  void getReviews() async {
    try {
      setBusy(true);
      final response = await api.allReview();
      reviews = response.reviews;
      setBusy(false);
    } catch (e) {
      setBusy(false);
    }
  }
}
