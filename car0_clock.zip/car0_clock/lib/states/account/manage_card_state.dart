import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class ManageCardState extends ViewModel {
  List<CardItem> cards = [];

  void getCards() async {
    try {
      setBusy(true);
      final response = await api.cards();
      cards = response.cards;
      setBusy(false);
    } catch (e) {
      setBusy(false);
    }
  }

  void remove(CardItem card, BuildContext context) async {
    alert!.confirmation(
      context: context,
      onPressed: () async {
        setNestedBusy(true);
        await api.removeCard(card.id);
        final response = await api.cards();
        cards = response.cards;
        setNestedBusy(false);
      },
    );
  }
}
