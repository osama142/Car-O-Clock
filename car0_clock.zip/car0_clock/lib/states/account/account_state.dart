import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class AccountState extends ViewModel {
  Future logout(BuildContext context) async {
    alert!.confirmation(
      context: context,
      onPressed: () async {
        setNestedBusy(true);
        await auth.logout();
        setNestedBusy(false);

        router.toAuthScreen(context, pop: true);
      },
    );
  }

  void openAuthScreen(BuildContext context) {
    router.toLoginScreen(context);
  }

  User get user => auth.user!;
}
