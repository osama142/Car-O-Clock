import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class EditProfileState extends ViewModel {
  final form = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final mobileController = TextEditingController();

  void init() {
    final user = auth.user!;

    nameController.text = user.name;
    emailController.text = user.email;
    mobileController.text = user.mobile;
  }

  void update(BuildContext context) async {
    if (!form.currentState!.validate()) return;

    final data = {
      'name': nameController.text,
      'email': emailController.text,
      'mobile': mobileController.text,
    };

    try {
      setBusy(true);
      final response = await api.profile(auth.user!.id, data);
      await auth.setResponse(response);
      init();
      setBusy(false);

      alert!.success(
        context: context,
        title: 'Profile Updated Successfully!',
      );
    } catch (e) {
      setBusy(false);
      alert!.error(
        context: context,
        title: 'Error',
        desc: e.toString(),
      );
    }
  }

  User get user => auth.user!;
}
