import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/states/state.dart';
import 'package:v1techx/v1techx.dart';

class MoreState extends ViewModel {
  void share() {
    final url = ShareLink.getStoreUrl(
      androidId: Constants.androidId,
      iosId: Constants.iosId,
    );

    ShareLink.share('${Constants.shareMessage} $url');
  }

  void review() {
    ShareLink.rate(
      androidId: Constants.androidId,
      iosId: Constants.iosId,
    );
  }
}
