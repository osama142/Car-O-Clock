import 'package:car_detailing/api/api.dart';
import 'package:v1techx/v1techx.dart';

import '../services/services.dart';

abstract class ViewModel extends BaseState {
  final api = locate<API>();
  final pref = locate<PreferenceService>();
  final auth = locate<AuthService>();
  final router = locate<RouterService>();
  final drawer = locate<DrawerService>();
  final settings = locate<SettingsService>();

  String get symbol => settings.symbol;
}
