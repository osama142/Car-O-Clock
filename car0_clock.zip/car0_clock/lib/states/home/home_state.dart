import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class HomeState extends ViewModel {
  List<Widget> images = [];
  List<Category> categories = [];

  void getCategory() async {
    try {
      setBusy(true);
      final response = await api.getHomeCategories();
      categories = response.categories;

      await settings.getSettings();

      images = response.sliders
          .map(
            (e) => ClipRRect(
              borderRadius: BorderRadius.circular(19),
              child: Image.network(e).p4(),
            ).px4(),
          )
          .toList();

      setBusy(false);
    } catch (e) {
      print(e.toString());
      setError(true, error: e.toString());
    }
  }

  void onDrawerChange(BuildContext context, int value) {
    drawer.onDrawerChange(context, value);
    notifyListeners();
  }

  void openAccount(BuildContext context) => router.toAccountScreen(context);

  void openServiceOrServices(BuildContext context, Category category) {
    if (category.id == 0) {
      router.toServicesScreen(context);
      return;
    }

    router.toServiceDetailsScreen(category, context);
  }

  void share() {
    final url = ShareLink.getStoreUrl(
      androidId: Constants.androidId,
      iosId: Constants.iosId,
    );

    ShareLink.share('${Constants.shareMessage} $url');
  }

  void review() {
    ShareLink.rate(
      androidId: Constants.androidId,
      iosId: Constants.iosId,
    );
  }
}
