import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class ServiceDetailsState extends ViewModel {
  late Category category;
  List<Category> categories = [];
  List<Service> services = [];
  List<Service> sortedServices = [];

  void getCategory(Category value) async {
    category = value;

    try {
      setBusy(true);
      final response = await api.getCategoryDetails(value.id);

      categories = response.categories;
      services = response.services;
      sortedServices = response.services;
      setBusy(false);
    } catch (e) {
      print(e.toString());
      setBusy(false);
    }
  }

  void sort(Category value) {
    categories.forEach((element) => element.selected = false);
    value.selected = true;

    if (value.id == 0) {
      sortedServices = services;
      notifyListeners();
      return;
    }

    sortedServices =
        services.where((el) => el.subcategoryId == value.id).toList();

    notifyListeners();
  }

  void openBookingModal(BuildContext context, Service service) {
    showModalBottomSheet(
      context: context,
      builder: (_) {
        return Column(
          children: [
            AppBar(
              leading: CloseButton(),
              title: 'Book Service'.text.make(),
              centerTitle: false,
              elevation: 0,
            ),
            Card(
              child: Column(
                children: [
                  ProgressImage(
                    url: service.image,
                    height: 100,
                    fit: BoxFit.cover,
                    width: context.width,
                  ),
                  service.name.text.bold.make(),
                  4.heightBox,
                  service.time.text.semiBold.make(),
                  4.heightBox,
                  service.description.text.caption(context).make(),
                  8.heightBox,
                  '£${service.price}'
                      .text
                      .semiBold
                      .size(18)
                      .color(context.primaryColor)
                      .make(),
                ],
              ),
            ).p8(),
            Spacer(),
            GFButton(
              onPressed: () {},
              shape: GFButtonShape.square,
              elevation: 4,
              fullWidthButton: true,
              child: 'PAY £300'.text.bold.make(),
            ).h(50),
          ],
        );
      },
    );
  }

  void openBookingScreen(BuildContext context, Service service) {
    router.toBookingScreen(service, context);
  }
}
