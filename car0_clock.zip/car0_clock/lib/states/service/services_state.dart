import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';

class ServicesState extends ViewModel {
  List<Category> categories = [];

  void getCategory() async {
    try {
      setBusy(true);
      final response = await api.getCategories();
      categories = response.categories;
      setBusy(false);
    } catch (e) {
      setError(true, error: e.toString());
    }
  }

  void openService(BuildContext context, Category category) {
    router.toServiceDetailsScreen(category, context);
  }
}
