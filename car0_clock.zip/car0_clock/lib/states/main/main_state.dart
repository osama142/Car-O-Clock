import 'package:car_detailing/screens/screens.dart';
import 'package:car_detailing/states/state.dart';

class MainState extends ViewModel {
  final screens = [
    HomeScreen(),
    MyBookingScreen(),
    AccountScreen(),
    MoreScreen(),
  ];

  void onPageChange(int value) {
    drawer.onPageChange(value);
    notifyListeners();
  }
}
