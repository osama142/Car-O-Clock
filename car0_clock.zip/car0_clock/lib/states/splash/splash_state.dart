import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

import '../state.dart';

class SplashState extends ViewModel {
  void init(BuildContext context) {
    Future.delayed(
      3.seconds,
      () => router.fromSplash(context),
    );
  }
}
