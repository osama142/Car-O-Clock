import 'package:car_detailing/commons/commons.dart';
import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:v1techx/v1techx.dart';

import '../state.dart';

class IntroState extends ViewModel {
  List<PageViewModel> pages() {
    final data = Constants.introductionScreens();

    final pages = <PageViewModel>[];

    for (final item in data) {
      final isLocal = item['is_asset'] as bool;

      final page = PageViewModel(
        title: item['title'] as String,
        body: item['body'] as String,
        image: (isLocal
                ? Image.asset(item['image'], height: 175)
                : Image.network(item['image'], height: 175))
            .centered(),
      );

      pages.add(page);
    }

    return pages;
  }

  void onDone(BuildContext context) {
    pref.setIntroStatus(true);
    router.toAuthScreen(context);
  }
}
