import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class BookingReviewState extends ViewModel {
  late Booking booking;

  final form = GlobalKey<FormState>();

  final reviewController = TextEditingController();
  num rating = 0;

  Review? review;

  void init(Booking value) {
    booking = value;
  }

  void getReview() async {
    setBusy(true);
    try {
      review = await api.showReview(booking.id);
      reviewController.text = review?.review ?? '';
      rating = review?.rating ?? 0;
      setBusy(false);
    } catch (e) {
      setBusy(false);
    }
  }

  void updateRating(double value) {
    rating = value;
  }

  void createReview(BuildContext context) async {
    if (!form.currentState!.validate()) return;

    try {
      setBusy(true);

      final data = {
        'review_id': review?.id,
        'user_id': auth.user?.id,
        'booking_id': booking.id,
        'service_id': booking.service.id,
        'rating': rating,
        'review': reviewController.text,
      };

      await api.bookingReview(data);
      setBusy(false);

      alert!.success(
        context: context,
        title: 'Thank You For Your Feedback!',
        label: 'CLOSE',
      );
    } catch (e) {
      setBusy(false);
      alert!.error(
        context: context,
        title: e.toString(),
      );
    }
  }
}
