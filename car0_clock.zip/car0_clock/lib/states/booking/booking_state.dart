import 'dart:convert';
import 'dart:io';

import 'package:car_detailing/commons/commons.dart';
import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/screens/booking/booking_question.dart';
import 'package:car_detailing/screens/booking/checkout_screen.dart';
import 'package:car_detailing/screens/booking/offer_screen.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:v1techx/v1techx.dart';

class BookingState extends ViewModel {
  final form = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final mobileController = TextEditingController();
  final vehicleController = TextEditingController();
  DateTime? date;
  String time = 'Time';

  late Service service;

  List<Tax> taxes = [];
  List<Offer> offers = [];
  num total = 0;

  Offer? offer;

  void init(Service value) {
    service = value;
    getTotal();
    getOffers();
  }

  void openQuestion(BuildContext context) async {
    if (!auth.isLoggedIn) {
      router.toLoginScreen(context);
      return;
    }

    final user = auth.user!;

    nameController.text = user.name;
    emailController.text = user.email;
    mobileController.text = user.mobile;

    final questionResult = await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => BookingQuestion(state: this),
      fullscreenDialog: true,
    ));

    if (questionResult == null) return;

    final result = await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => CheckoutScreen(state: this),
      fullscreenDialog: true,
    ));

    if (result == 'cash') {
      payByCash(context);
    } else {
      payByCard(context);
    }
  }

  void validate(BuildContext context) {
    if (!form.currentState!.validate()) return;

    if (date == null) {
      alert!.error(
        context: context,
        title: 'Please choose a date!',
      );
      return;
    }

    if (time == 'Time') {
      alert!.error(
        context: context,
        title: 'Please choose a time!',
      );
      return;
    }

    context.pop('ok');
  }

  void payByCash(BuildContext context) async {
    if (!auth.isLoggedIn) {
      router.toLoginScreen(context);
      return;
    }

    await book(context, 'cash');
  }

  void payByCard(BuildContext context) async {
    if (!auth.isLoggedIn) {
      router.toLoginScreen(context);
      return;
    }

    setNestedBusy(true);

    final response = await api.stripeSheet({'id': service.id, 'amount': total});

    Stripe.publishableKey = response.publicKey;

    await Stripe.instance.initPaymentSheet(
      paymentSheetParameters: SetupPaymentSheetParameters(
        applePay: false,
        googlePay: false,
        testEnv: true,
        style: ThemeMode.light,
        customerId: response.customerId,
        merchantCountryCode: Constants.stripeCountry,
        merchantDisplayName: Constants.stripeShopName,
        paymentIntentClientSecret: response.paymentIntent,
        customerEphemeralKeySecret: response.ephemeralKey,
      ),
    );

    try {
      await Stripe.instance.presentPaymentSheet();

      setNestedBusy(false);

      await book(context, 'stripe');
    } catch (e) {
      setNestedBusy(false);
      alert!.error(
        context: context,
        title: 'Payment cancelled!',
      );
    }
  }

  void openOffers(BuildContext context) async {
    final result = await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => OfferScreen(offers: offers),
      fullscreenDialog: true,
    ));

    if (result == null) return;

    offer = result;

    if (offer!.minimumAmount >= total) {
      alert!.error(
        context: context,
        title: 'Unable to Apply Coupon!',
        desc: 'Minimum Checkout Amount $symbol${offer!.minimumAmount}',
      );
      offer = null;
    }

    notifyListeners();
    getTotal();
  }

  Future book(BuildContext context, String method) async {
    setNestedBusy(true);
    final data = {
      'name': nameController.text,
      'email': emailController.text,
      'phone': mobileController.text,
      'vehicle': vehicleController.text,
      'date': date!.toIso8601String(),
      'time': time,
      'service_id': service.id,
      'payment_method': method,
      'total': total,
      'answers': jsonEncode(service.questions),
    };
    await api.book(data);

    setNestedBusy(false);

    router.toSuccessScreen(context);
  }

  void pickDate(BuildContext context) async {
    if (Platform.isAndroid) {
      final result = await showDatePicker(
        context: context,
        initialDate: date ?? DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime.now().add(365.days),
      );

      date = result;
      notifyListeners();
    } else {
      DatePicker.showDatePicker(
        context,
        showTitleActions: true,
        minTime: DateTime.now(),
        maxTime: DateTime.now().add(365.days),
        currentTime: date ?? DateTime.now(),
        onConfirm: (result) {
          date = result;
          notifyListeners();
        },
      );
    }
  }

  void pickTime(BuildContext context) async {
    if (Platform.isAndroid) {
      final result = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );

      if (result == null) return;

      time = result.format(context);
      notifyListeners();
    } else {
      DatePicker.showTimePicker(
        context,
        showTitleActions: true,
        onConfirm: (result) {
          time = TimeOfDay.fromDateTime(result).format(context);
          notifyListeners();
        },
      );
    }
  }

  void getTotal() async {
    setNestedBusy(true);
    final response = await api.calculate(service.id, offer: offer?.id);
    total = response.total;
    taxes = response.taxes;
    setNestedBusy(false);
  }

  void getOffers() async {
    setNestedBusy(true);
    final response = await api.getOffers();
    offers = response.offers;
    setNestedBusy(false);
  }

  String get stringDate => date != null ? parseDate(date!) : 'Date';
}
