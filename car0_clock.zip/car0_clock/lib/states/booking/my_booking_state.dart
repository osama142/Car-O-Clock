import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';
import 'package:flutter/material.dart';

class MyBookingState extends ViewModel {
  List<Booking> bookings = [];

  void getBookings() async {
    if (!auth.isLoggedIn) return;

    setBusy(true);

    try {
      final response = await api.bookings();
      bookings = response.bookings;
      setBusy(false);
    } catch (e) {
      print(e.toString());
      setError(true);
    }
  }

  void openAuthScreen(BuildContext context) {
    router.toLoginScreen(context);
  }
}
