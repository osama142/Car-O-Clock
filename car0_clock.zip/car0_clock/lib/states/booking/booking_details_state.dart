import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/states/state.dart';

class BookingDetailsState extends ViewModel {
  late Booking booking;

  void init(Booking value) {
    booking = value;
  }
}
