import 'package:car_detailing/states/state.dart';

class SuccessState extends ViewModel {}
