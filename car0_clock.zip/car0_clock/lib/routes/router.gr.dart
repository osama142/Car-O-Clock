// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouteGenerator
// **************************************************************************

import 'package:auto_route/auto_route.dart' as _i2;
import 'package:flutter/material.dart' as _i3;

import '../models/models.dart' as _i5;
import '../screens/screens.dart' as _i1;

class AppRouter extends _i2.RootStackRouter {
  AppRouter(
      {_i3.GlobalKey<_i3.NavigatorState>? navigatorKey,
      required this.authGuard})
      : super(navigatorKey);

  final _i4.AuthGuard authGuard;

  @override
  final Map<String, _i2.PageFactory> pagesMap = {
    SplashRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.SplashScreen());
    },
    IntroRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.IntroScreen());
    },
    AuthRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.AuthScreen());
    },
    LoginRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.LoginScreen());
    },
    RegisterRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.RegisterScreen());
    },
    MainRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.MainScreen());
    },
    ServicesRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.ServicesScreen());
    },
    ServiceDetailsRoute.name: (routeData) {
      final args = routeData.argsAs<ServiceDetailsRouteArgs>();
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child:
              _i1.ServiceDetailsScreen(key: args.key, category: args.category));
    },
    ContactUsRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.ContactUsScreen());
    },
    BookingRoute.name: (routeData) {
      final args = routeData.argsAs<BookingRouteArgs>();
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child: _i1.BookingScreen(key: args.key, service: args.service),
          fullscreenDialog: true);
    },
    BookingReview.name: (routeData) {
      final args = routeData.argsAs<BookingReviewArgs>();
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child: _i1.BookingReview(key: args.key, booking: args.booking),
          fullscreenDialog: true);
    },
    EditProfileRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child: const _i1.EditProfileScreen(),
          fullscreenDialog: true);
    },
    ForgotPasswordRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child: const _i1.ForgotPasswordScreen(),
          fullscreenDialog: true);
    },
    AllReviewRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.AllReviewScreen());
    },
    ReviewRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.ReviewScreen());
    },
    HelpRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.HelpScreen());
    },
    SuccessRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.SuccessScreen());
    },
    BookingDetailsRoute.name: (routeData) {
      final args = routeData.argsAs<BookingDetailsRouteArgs>();
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child:
              _i1.BookingDetailsScreen(key: args.key, booking: args.booking));
    },
    PasswordRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child: const _i1.PasswordScreen(),
          fullscreenDialog: true);
    },
    HTMLRoute.name: (routeData) {
      final args = routeData.argsAs<HTMLRouteArgs>();
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child:
              _i1.HTMLScreen(key: args.key, title: args.title, data: args.data),
          fullscreenDialog: true);
    },
    FaqRoute.name: (routeData) {
      final args = routeData.argsAs<FaqRouteArgs>();
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child: _i1.FaqScreen(key: args.key, faqs: args.faqs),
          fullscreenDialog: true);
    },
    MyBookingRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.MyBookingScreen());
    },
    AccountRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.AccountScreen());
    },
    ManageCardRoute.name: (routeData) {
      return _i2.MaterialPageX<dynamic>(
          routeData: routeData,
          child: const _i1.ManageCardScreen(),
          fullscreenDialog: true);
    }
  };

  @override
  List<_i2.RouteConfig> get routes => [
        _i2.RouteConfig(SplashRoute.name, path: '/'),
        _i2.RouteConfig(IntroRoute.name, path: '/intro-screen'),
        _i2.RouteConfig(AuthRoute.name, path: '/auth-screen'),
        _i2.RouteConfig(LoginRoute.name, path: '/login-screen'),
        _i2.RouteConfig(RegisterRoute.name, path: '/register-screen'),
        _i2.RouteConfig(MainRoute.name, path: '/main-screen'),
        _i2.RouteConfig(ServicesRoute.name, path: '/services-screen'),
        _i2.RouteConfig(ServiceDetailsRoute.name,
            path: '/service-details-screen'),
        _i2.RouteConfig(ContactUsRoute.name, path: '/contact-us-screen'),
        _i2.RouteConfig(BookingRoute.name, path: '/booking-screen'),
        _i2.RouteConfig(BookingReview.name, path: '/booking-review'),
        _i2.RouteConfig(EditProfileRoute.name, path: '/edit-profile-screen'),
        _i2.RouteConfig(ForgotPasswordRoute.name,
            path: '/forgot-password-screen'),
        _i2.RouteConfig(AllReviewRoute.name, path: '/all-review-screen'),
        _i2.RouteConfig(ReviewRoute.name, path: '/review-screen'),
        _i2.RouteConfig(HelpRoute.name, path: '/help-screen'),
        _i2.RouteConfig(SuccessRoute.name, path: '/success-screen'),
        _i2.RouteConfig(BookingDetailsRoute.name,
            path: '/booking-details-screen'),
        _i2.RouteConfig(PasswordRoute.name, path: '/password-screen'),
        _i2.RouteConfig(HTMLRoute.name, path: '/h-tm-lScreen'),
        _i2.RouteConfig(FaqRoute.name, path: '/faq-screen'),
        _i2.RouteConfig(MyBookingRoute.name,
            path: '/my-booking-screen', guards: []),
        _i2.RouteConfig(AccountRoute.name,
            path: '/account-screen', guards: []),
        _i2.RouteConfig(ManageCardRoute.name, path: '/manage-card-screen')
      ];
}

/// generated route for [_i1.SplashScreen]
class SplashRoute extends _i2.PageRouteInfo<void> {
  const SplashRoute() : super(name, path: '/');

  static const String name = 'SplashRoute';
}

/// generated route for [_i1.IntroScreen]
class IntroRoute extends _i2.PageRouteInfo<void> {
  const IntroRoute() : super(name, path: '/intro-screen');

  static const String name = 'IntroRoute';
}

/// generated route for [_i1.AuthScreen]
class AuthRoute extends _i2.PageRouteInfo<void> {
  const AuthRoute() : super(name, path: '/auth-screen');

  static const String name = 'AuthRoute';
}

/// generated route for [_i1.LoginScreen]
class LoginRoute extends _i2.PageRouteInfo<void> {
  const LoginRoute() : super(name, path: '/login-screen');

  static const String name = 'LoginRoute';
}

/// generated route for [_i1.RegisterScreen]
class RegisterRoute extends _i2.PageRouteInfo<void> {
  const RegisterRoute() : super(name, path: '/register-screen');

  static const String name = 'RegisterRoute';
}

/// generated route for [_i1.MainScreen]
class MainRoute extends _i2.PageRouteInfo<void> {
  const MainRoute() : super(name, path: '/main-screen');

  static const String name = 'MainRoute';
}

/// generated route for [_i1.ServicesScreen]
class ServicesRoute extends _i2.PageRouteInfo<void> {
  const ServicesRoute() : super(name, path: '/services-screen');

  static const String name = 'ServicesRoute';
}

/// generated route for [_i1.ServiceDetailsScreen]
class ServiceDetailsRoute extends _i2.PageRouteInfo<ServiceDetailsRouteArgs> {
  ServiceDetailsRoute({_i3.Key? key, required _i5.Category category})
      : super(name,
            path: '/service-details-screen',
            args: ServiceDetailsRouteArgs(key: key, category: category));

  static const String name = 'ServiceDetailsRoute';
}

class ServiceDetailsRouteArgs {
  const ServiceDetailsRouteArgs({this.key, required this.category});

  final _i3.Key? key;

  final _i5.Category category;
}

/// generated route for [_i1.ContactUsScreen]
class ContactUsRoute extends _i2.PageRouteInfo<void> {
  const ContactUsRoute() : super(name, path: '/contact-us-screen');

  static const String name = 'ContactUsRoute';
}

/// generated route for [_i1.BookingScreen]
class BookingRoute extends _i2.PageRouteInfo<BookingRouteArgs> {
  BookingRoute({_i3.Key? key, required _i5.Service service})
      : super(name,
            path: '/booking-screen',
            args: BookingRouteArgs(key: key, service: service));

  static const String name = 'BookingRoute';
}

class BookingRouteArgs {
  const BookingRouteArgs({this.key, required this.service});

  final _i3.Key? key;

  final _i5.Service service;
}

/// generated route for [_i1.BookingReview]
class BookingReview extends _i2.PageRouteInfo<BookingReviewArgs> {
  BookingReview({_i3.Key? key, required _i5.Booking booking})
      : super(name,
            path: '/booking-review',
            args: BookingReviewArgs(key: key, booking: booking));

  static const String name = 'BookingReview';
}

class BookingReviewArgs {
  const BookingReviewArgs({this.key, required this.booking});

  final _i3.Key? key;

  final _i5.Booking booking;
}

/// generated route for [_i1.EditProfileScreen]
class EditProfileRoute extends _i2.PageRouteInfo<void> {
  const EditProfileRoute() : super(name, path: '/edit-profile-screen');

  static const String name = 'EditProfileRoute';
}

/// generated route for [_i1.ForgotPasswordScreen]
class ForgotPasswordRoute extends _i2.PageRouteInfo<void> {
  const ForgotPasswordRoute() : super(name, path: '/forgot-password-screen');

  static const String name = 'ForgotPasswordRoute';
}

/// generated route for [_i1.AllReviewScreen]
class AllReviewRoute extends _i2.PageRouteInfo<void> {
  const AllReviewRoute() : super(name, path: '/all-review-screen');

  static const String name = 'AllReviewRoute';
}

/// generated route for [_i1.ReviewScreen]
class ReviewRoute extends _i2.PageRouteInfo<void> {
  const ReviewRoute() : super(name, path: '/review-screen');

  static const String name = 'ReviewRoute';
}

/// generated route for [_i1.HelpScreen]
class HelpRoute extends _i2.PageRouteInfo<void> {
  const HelpRoute() : super(name, path: '/help-screen');

  static const String name = 'HelpRoute';
}

/// generated route for [_i1.SuccessScreen]
class SuccessRoute extends _i2.PageRouteInfo<void> {
  const SuccessRoute() : super(name, path: '/success-screen');

  static const String name = 'SuccessRoute';
}

/// generated route for [_i1.BookingDetailsScreen]
class BookingDetailsRoute extends _i2.PageRouteInfo<BookingDetailsRouteArgs> {
  BookingDetailsRoute({_i3.Key? key, required _i5.Booking booking})
      : super(name,
            path: '/booking-details-screen',
            args: BookingDetailsRouteArgs(key: key, booking: booking));

  static const String name = 'BookingDetailsRoute';
}

class BookingDetailsRouteArgs {
  const BookingDetailsRouteArgs({this.key, required this.booking});

  final _i3.Key? key;

  final _i5.Booking booking;
}

/// generated route for [_i1.PasswordScreen]
class PasswordRoute extends _i2.PageRouteInfo<void> {
  const PasswordRoute() : super(name, path: '/password-screen');

  static const String name = 'PasswordRoute';
}

/// generated route for [_i1.HTMLScreen]
class HTMLRoute extends _i2.PageRouteInfo<HTMLRouteArgs> {
  HTMLRoute({_i3.Key? key, required String title, required String data})
      : super(name,
            path: '/h-tm-lScreen',
            args: HTMLRouteArgs(key: key, title: title, data: data));

  static const String name = 'HTMLRoute';
}

class HTMLRouteArgs {
  const HTMLRouteArgs({this.key, required this.title, required this.data});

  final _i3.Key? key;

  final String title;

  final String data;
}

/// generated route for [_i1.FaqScreen]
class FaqRoute extends _i2.PageRouteInfo<FaqRouteArgs> {
  FaqRoute({_i3.Key? key, required List<_i5.Faq> faqs})
      : super(name,
            path: '/faq-screen', args: FaqRouteArgs(key: key, faqs: faqs));

  static const String name = 'FaqRoute';
}

class FaqRouteArgs {
  const FaqRouteArgs({this.key, required this.faqs});

  final _i3.Key? key;

  final List<_i5.Faq> faqs;
}

/// generated route for [_i1.MyBookingScreen]
class MyBookingRoute extends _i2.PageRouteInfo<void> {
  const MyBookingRoute() : super(name, path: '/my-booking-screen');

  static const String name = 'MyBookingRoute';
}

/// generated route for [_i1.AccountScreen]
class AccountRoute extends _i2.PageRouteInfo<void> {
  const AccountRoute() : super(name, path: '/account-screen');

  static const String name = 'AccountRoute';
}

/// generated route for [_i1.ManageCardScreen]
class ManageCardRoute extends _i2.PageRouteInfo<void> {
  const ManageCardRoute() : super(name, path: '/manage-card-screen');

  static const String name = 'ManageCardRoute';
}
