import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class DrawerService {
  int currentIndex = 0;

  void onPageChange(int value) {
    currentIndex = value;
  }

  void onDrawerChange(BuildContext context, int value) {
    context.pop();
    currentIndex = value;
  }

  Color? activeColor(int value) {
    if (currentIndex == value) return Colors.blue.shade800;

    return null;
  }
}
