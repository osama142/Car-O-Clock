import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/services/preference_service.dart';
import 'package:v1techx/v1techx.dart';

class AuthService {
  final pref = locate<PreferenceService>();

  Future setResponse(AuthResponse response) async {
    await pref.setAuthResponse(response);
  }

  Future logout() async => await pref.logout();

  bool get isLoggedIn => pref.isLoggedIn;

  User? get user => pref.getUser();

  String? get token => pref.getToken();
}
