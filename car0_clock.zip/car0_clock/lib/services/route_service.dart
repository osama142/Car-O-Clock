import 'package:car_detailing/models/models.dart';
import 'package:car_detailing/routes/router.gr.dart';
import 'package:car_detailing/services/services.dart';
import 'package:flutter/material.dart';
import 'package:v1techx/v1techx.dart';

class RouterService {
  /// Determine where to go after splash has been shown
  void fromSplash(BuildContext context) {
    final pref = locate<PreferenceService>();

    if (!pref.isIntroShown) {
      toIntroScreen(context);
      return;
    }

    if (!pref.isAuthShown) {
      toAuthScreen(context);
      return;
    }

    toMainScreen(context);
  }

  /// IntroScreen
  void toIntroScreen(BuildContext context) {
    context.router.replace(IntroRoute());
  }

  /// AuthScreen
  void toAuthScreen(BuildContext context, {bool pop = false}) {
    if (pop) {
      context.router.pushAndPopUntil(
        AuthRoute(),
        predicate: (_) => false,
      );
      return;
    }

    context.router.replace(AuthRoute());
  }

  /// Auth : ForgotPasswordScreen
  void toForgotScreen(BuildContext context) {
    context.router.push(ForgotPasswordRoute());
  }

  /// LoginScreen
  void toLoginScreen(BuildContext context, {bool replace = false}) {
    if (replace) {
      context.router.replace(LoginRoute());
    } else {
      context.router.push(LoginRoute());
    }
  }

  /// RegisterScreen
  void toRegisterScreen(BuildContext context, {bool replace = false}) {
    if (replace) {
      context.router.replace(RegisterRoute());
    } else {
      context.router.push(RegisterRoute());
    }
  }

  /// MainScreen
  void toMainScreen(BuildContext context) {
    context.router.pushAndPopUntil(
      MainRoute(),
      predicate: (_) => false,
    );
  }

  /// ServicesScreen
  void toServicesScreen(BuildContext context) {
    context.router.push(ServicesRoute());
  }

  /// ServicesScreen
  void toServiceDetailsScreen(Category category, BuildContext context) {
    context.router.push(ServiceDetailsRoute(category: category));
  }

  /// ServicesScreen
  void toBookingScreen(Service item, BuildContext context) {
    context.router.push(BookingRoute(service: item));
  }

  /// AccountScreen
  void toAccountScreen(BuildContext context) {
    context.router.push(AccountRoute());
  }

  /// AccountScreen: All Review Screen
  void toAllReviewScreen(BuildContext context) {
    context.router.push(AllReviewRoute());
  }

  /// BookingScreen: All Bookings
  void toMyBookingScreen(BuildContext context, {bool replace = false}) {
    if (replace) {
      context.router.replace(MyBookingRoute());
      return;
    }

    context.router.push(MyBookingRoute());
  }

  /// BookingScreen: Booking Details
  void toBookingDetailsScreen(BuildContext context, Booking booking) {
    context.router.push(BookingDetailsRoute(booking: booking));
  }

  /// BookingScreen: Booking Review
  void toBookingReviewScreen(BuildContext context, Booking booking) {
    context.router.push(BookingReview(booking: booking));
  }

  void toSuccessScreen(BuildContext context) {
    context.router.replace(SuccessRoute());
  }

  /// EditProfileScreen
  void toEditProfileScreen(BuildContext context) {
    context.router.push(EditProfileRoute());
  }

  /// ManageCardScreen
  void toManageCardScreen(BuildContext context) {
    context.router.push(ManageCardRoute());
  }

  /// ChangePasswordScreen
  void toChangePasswordScreen(BuildContext context) {
    context.router.push(PasswordRoute());
  }

  /// Common
  /// Contact Us Screen
  void toContactScreen(BuildContext context) {
    context.router.push(ContactUsRoute());
  }

  /// Common
  /// Review Screen
  void toReviewScreen(BuildContext context) {
    context.router.push(ReviewRoute());
  }

  /// Common
  /// Help Screen
  void toHelpScreen(BuildContext context) {
    context.router.push(HelpRoute());
  }

  /// Common
  /// Help Screen
  void toHtmlScreen(BuildContext context, String title, String data) {
    context.router.push(HTMLRoute(title: title, data: data));
  }

  /// Common
  /// Help Screen
  void toFaqScreen(BuildContext context, List<Faq> faqs) {
    context.router.push(FaqRoute(faqs: faqs));
  }
}
