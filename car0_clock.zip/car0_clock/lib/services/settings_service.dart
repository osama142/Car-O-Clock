import 'package:car_detailing/api/api.dart';
import 'package:v1techx/v1techx.dart';

class SettingsService {
  final api = locate<API>();

  String symbol = '£';
  String code = 'GBP';

  Future getSettings() async {
    final data = await api.getSettings();
    symbol = data['symbol'];
    code = data['code'];
  }
}
