import 'dart:convert';

import 'package:car_detailing/models/models.dart';
import 'package:v1techx/v1techx.dart';

class PreferenceService {
  static PreferenceService? _instance;
  static SharedPreferences? _prefs;

  static const kIsIntroShown = 'is-intro-shown';
  static const kIsAuthShown = 'is-auth-shown';
  static const kIsLoggedIn = 'is-logged-in';
  static const kAuthResponse = 'auth-response';

  static Future<PreferenceService?> getInstance() async {
    _instance ??= PreferenceService();
    _prefs ??= await SharedPreferences.getInstance();
    return _instance;
  }

  Future setAuthResponse(AuthResponse response) async {
    await _prefs!.setString(kAuthResponse, jsonEncode(response.toJson()));
    setLoginStatus(true);
    setAuthStatus(true);
    setIntroStatus(true);
  }

  Map<String, dynamic> getAuthResponse() {
    final source = _prefs!.getString(kAuthResponse);

    return jsonDecode(source ?? '');
  }

  User? getUser() {
    if (!isLoggedIn) return null;

    return User.fromJson(getAuthResponse()['user']);
  }

  String? getToken() {
    if (!isLoggedIn) return null;

    return getAuthResponse()['token'];
  }

  Future logout() async {
    _prefs!.remove(kAuthResponse);
    _prefs!.remove(kIsLoggedIn);
  }

  bool get isIntroShown => _prefs!.getBool(kIsIntroShown) ?? false;

  bool get isAuthShown => _prefs!.getBool(kIsAuthShown) ?? false;

  bool get isLoggedIn => _prefs!.getBool(kIsLoggedIn) ?? false;

  void setIntroStatus(bool status) => _prefs!.setBool(kIsIntroShown, status);

  void setAuthStatus(bool status) => _prefs!.setBool(kIsAuthShown, status);

  void setLoginStatus(bool status) => _prefs!.setBool(kIsLoggedIn, status);
}
