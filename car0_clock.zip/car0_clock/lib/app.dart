import 'package:car_detailing/theme/style.dart';
import 'package:flutter/material.dart';

import 'routes/auth_guard.dart';
import 'routes/router.gr.dart';

class App extends StatelessWidget {
  final _appRouter = AppRouter(authGuard: AuthGuard());

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'V1 Garage Services',
      theme: theme,
      debugShowCheckedModeBanner: false,
      routerDelegate: _appRouter.delegate(),
      routeInformationParser: _appRouter.defaultRouteParser(),
    );
  }
}
