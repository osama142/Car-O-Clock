package com.example.car0_clock

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
